from setuptools import setup, find_packages

setup(
    name="hardware_optimiser",
    version="5.0.0",
    description="Abstract, domain-agnostic hardware design optimiser — v5",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "numpy",
        "scipy",
        "scikit-learn",
    ],
    extras_require={
        "jax":   ["jax", "jaxlib"],
        "pareto": ["pymoo"],
        "yaml":  ["pyyaml"],
        "dashboard": ["streamlit", "plotly", "pandas"],
        "all":   ["jax", "jaxlib", "pymoo", "pyyaml",
                  "streamlit", "plotly", "pandas"],
    },
    entry_points={
        "console_scripts": [
            "hardware-optimiser=hardware_optimiser.cli:main",
        ],
    },
)
