"""
hardware_optimiser.optimizers
==============================
All concrete optimizer classes:

  GenericOptimizer             — SLSQP with JAX Jacobian (§7)
  FeasibilityRepair            — project to feasible region  (§7b)
  ParallelSLSQPEvaluator       — ProcessPoolExecutor batch eval (§7c)
  DifferentialEvolutionOptimizer — DE + SLSQP polish  (§8)
  ParallelMultiStartOptimizer  — threaded multi-start (§8b)
  NSGAParetoOptimizer          — NSGA-II / NSGA-III via pymoo (§8c)
  ParetoSolution / ParetoFront — result dataclasses (§8c)
"""

from __future__ import annotations

import csv
import json
import logging
import time
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple, Type

import numpy as np
from scipy.optimize import differential_evolution, minimize

from ._compat import (
    PYMOO_AVAILABLE,
    NSGA2, NSGA3, PymooProblem,
    pymoo_minimize, get_reference_directions,
)
from .autodiff import GradientBackend, JaxGradientProvider, make_jax_objective
from .config import DomainConfig
from .constraints import ConstraintKind, ConstraintSet
from .interfaces import AbstractEvaluator, AbstractOptimizer, OptimResult
from .objective import WeightedObjective

log = logging.getLogger("hardware_optimiser")


# =============================================================================
# §7  GENERIC SLSQP OPTIMIZER
# =============================================================================

class GenericOptimizer(AbstractOptimizer):
    """
    SLSQP optimizer with JAX-computed (or finite-difference) Jacobian.

    Soft-constraint penalties are added to the objective; hard constraints
    are passed to SLSQP as ``eq``/``ineq`` constraint dicts.
    """

    def __init__(
        self,
        evaluator:   AbstractEvaluator,
        objective:   WeightedObjective,
        design_vars: List[Tuple[str, Tuple[float, float]]],
        cset:        ConstraintSet,
        backend:     GradientBackend = GradientBackend.JAX,
    ) -> None:
        self._ev      = evaluator
        self._obj     = objective
        self._dvars   = design_vars
        self._cset    = cset
        self._backend = backend
        self._dvar_names = [n for n, _ in design_vars]

    def _unpack(self, x: np.ndarray, base: Dict[str, float]) -> Dict[str, float]:
        p = dict(base)
        for i, (n, _) in enumerate(self._dvars):
            p[n] = float(x[i])
        return p

    def optimize_design(
        self,
        initial_params: Dict[str, float],
        x0_override: Optional[np.ndarray] = None,
    ) -> OptimResult:
        x0 = (x0_override if x0_override is not None
              else np.array([initial_params.get(n, 0.5 * (lo + hi))
                             for n, (lo, hi) in self._dvars]))
        bounds = [b for _, b in self._dvars]
        cons   = self._cset.slsqp_constraints(initial_params)

        flat_obj = make_jax_objective(self._ev, self._obj, self._dvars, initial_params)

        def _scipy_obj(x: np.ndarray) -> float:
            return float(flat_obj(np.asarray(x, dtype=float))) + \
                   self._cset.penalty(x, initial_params)

        grad_provider = JaxGradientProvider(
            lambda x: float(flat_obj(np.asarray(x, dtype=float))),
            self._dvars,
            backend=self._backend,
        )

        t0  = time.perf_counter()
        res = minimize(
            _scipy_obj, x0,
            bounds=bounds, constraints=cons,
            method="SLSQP",
            jac=grad_provider.jac_callable(),
            options={"ftol": 1e-9, "maxiter": 500},
        )
        elapsed    = time.perf_counter() - t0
        opt_params = self._unpack(res.x, initial_params)
        feasible   = self._cset.hard_feasible(res.x, initial_params)
        return OptimResult(
            optimized_params=opt_params,
            results=self._ev.evaluate(opt_params),
            objective_value=float(res.fun),
            success=bool(res.success),
            message=str(res.message),
            n_iter=int(res.nit),
            elapsed_s=elapsed,
            feasible=feasible,
        )


# =============================================================================
# §7b  FEASIBILITY REPAIR
# =============================================================================

class FeasibilityRepair:
    """
    Post-process an OptimResult:

    1. Check whether all HARD constraints are satisfied.
    2. If not, solve  min ‖x − x*‖²  s.t. hard constraints + bounds
       (nearest-feasible-point projection).
    3. Re-evaluate and flag the result.
    """

    def __init__(
        self,
        design_vars: List[Tuple[str, Tuple[float, float]]],
        evaluator:   AbstractEvaluator,
        cset:        ConstraintSet,
        tol:         float = 1e-6,
    ) -> None:
        self._dvars      = design_vars
        self._ev         = evaluator
        self._cset       = cset
        self._tol        = tol
        self._dvar_names = [n for n, _ in design_vars]

    def _x(self, p: Dict[str, float]) -> np.ndarray:
        return np.array([p.get(n, 0.0) for n in self._dvar_names])

    def _p(self, x: np.ndarray, base: Dict[str, float]) -> Dict[str, float]:
        p = dict(base)
        for i, n in enumerate(self._dvar_names):
            p[n] = float(x[i])
        return p

    def repair(self, result: OptimResult) -> OptimResult:
        base   = result.optimized_params
        x_star = self._x(base)

        if self._cset.hard_feasible(x_star, base):
            return OptimResult(**{**result.__dict__, "feasible": True})

        n_viol = sum(1 for v in self._cset.violations(x_star, base).values()
                     if v > self._tol)
        log.info("FeasibilityRepair: %d violation(s) — projecting.", n_viol)

        bounds     = [b for _, b in self._dvars]
        cons_scipy = self._cset.slsqp_constraints(base)

        rep = minimize(
            lambda x: float(np.dot(x - x_star, x - x_star)),
            x_star,
            jac=lambda x: 2.0 * (x - x_star),
            bounds=bounds, constraints=cons_scipy,
            method="SLSQP",
            options={"ftol": 1e-10, "maxiter": 400},
        )
        x_rep          = rep.x
        feasible_after = self._cset.hard_feasible(x_rep, base)
        if not feasible_after:
            log.warning("FeasibilityRepair: residual violations remain.")

        rep_params  = self._p(x_rep, base)
        rep_results = self._ev.evaluate(rep_params)
        return OptimResult(
            optimized_params=rep_params,
            results=rep_results,
            objective_value=result.objective_value,
            success=result.success and feasible_after,
            message=result.message + " [repaired]",
            n_iter=result.n_iter,
            elapsed_s=result.elapsed_s,
            feasible=feasible_after,
        )


# =============================================================================
# §7c  PARALLEL SLSQP EVALUATOR
# =============================================================================

# Module-level evaluator singleton — populated in each worker process.
_PARALLEL_EVALUATOR: Optional[AbstractEvaluator] = None


def _worker_init_v5(domain_name: str, config_dict: Dict[str, Any]) -> None:
    """Initialise per-process evaluator once per worker."""
    global _PARALLEL_EVALUATOR
    from .config  import DomainConfig
    from .factory import get_domain           # lazy to avoid circular

    cfg = DomainConfig(
        params=config_dict.get("params", {}),
        bounds={k: tuple(v) for k, v in config_dict.get("bounds", {}).items()},  # type: ignore
        weights=config_dict.get("weights", {}),
        tols=config_dict.get("tols", {}),
        mass_models=config_dict.get("mass_models", {}),
        objectives=config_dict.get("objectives", []),
    )
    _PARALLEL_EVALUATOR = get_domain(domain_name, cfg).evaluator


def _worker_eval_v5(params_dict: Dict[str, float]) -> Dict[str, Any]:
    assert _PARALLEL_EVALUATOR is not None, "Worker not initialised"
    try:
        r = _PARALLEL_EVALUATOR.evaluate(params_dict)
        return {k: v for k, v in r.items() if k != "geometry"}
    except Exception as exc:
        return {"__error__": str(exc)}


class ParallelSLSQPEvaluator:
    """
    Context-manager wrapper that batch-evaluates parameter dicts in
    subprocesses via ``ProcessPoolExecutor``.

    Usage::

        with ParallelSLSQPEvaluator("nozzle", cfg, max_workers=4) as pe:
            results = pe.evaluate_batch(param_list)
    """

    def __init__(
        self,
        domain_name: str,
        config:      DomainConfig,
        max_workers: int = 4,
    ) -> None:
        self._domain_name = domain_name
        self._max_workers = max_workers
        self._cfg_dict = {
            "params":      config.params,
            "bounds":      {k: list(v) for k, v in config.bounds.items()},
            "weights":     config.weights,
            "tols":        config.tols,
            "mass_models": config.mass_models,
            "objectives":  config.objectives,
        }
        self._pool: Optional[ProcessPoolExecutor] = None

    def __enter__(self) -> "ParallelSLSQPEvaluator":
        self._pool = ProcessPoolExecutor(
            max_workers=self._max_workers,
            initializer=_worker_init_v5,
            initargs=(self._domain_name, self._cfg_dict),
        )
        return self

    def __exit__(self, *_: Any) -> None:
        if self._pool:
            self._pool.shutdown(wait=True)

    def evaluate_batch(
        self, param_list: List[Dict[str, float]]
    ) -> List[Dict[str, Any]]:
        if not self._pool:
            raise RuntimeError("Use as context manager.")
        futures = {self._pool.submit(_worker_eval_v5, p): i
                   for i, p in enumerate(param_list)}
        results: Dict[int, Dict[str, Any]] = {}
        for fut in as_completed(futures):
            idx = futures[fut]
            try:
                results[idx] = fut.result()
            except Exception as exc:
                log.warning("Parallel eval idx=%d failed: %s", idx, exc)
                results[idx] = {}
        return [results[i] for i in range(len(param_list))]


# =============================================================================
# §8  DIFFERENTIAL EVOLUTION + SLSQP POLISH
# =============================================================================

class DifferentialEvolutionOptimizer(AbstractOptimizer):
    """Global DE search followed by optional SLSQP local polish."""

    def __init__(
        self,
        evaluator:   AbstractEvaluator,
        objective:   WeightedObjective,
        design_vars: List[Tuple[str, Tuple[float, float]]],
        cset:        ConstraintSet,
        de_seed:     int  = 0,
        polish:      bool = True,
    ) -> None:
        self._ev      = evaluator
        self._obj     = objective
        self._dvars   = design_vars
        self._cset    = cset
        self._de_seed = de_seed
        self._polish  = polish

    def _unpack(self, x: np.ndarray, base: Dict[str, float]) -> Dict[str, float]:
        p = dict(base)
        for i, (n, _) in enumerate(self._dvars):
            p[n] = float(x[i])
        return p

    def optimize_design(
        self,
        initial_params: Dict[str, float],
        x0_override: Optional[np.ndarray] = None,
    ) -> OptimResult:
        bounds = [b for _, b in self._dvars]

        def _de_obj(x: np.ndarray) -> float:
            p   = self._unpack(x, initial_params)
            val = self._obj(self._ev.evaluate(p))
            val += self._cset.penalty(x, initial_params)
            for c in self._cset._all:
                if c.kind != ConstraintKind.SOFT:
                    v = c.fun(x, initial_params)
                    if v < 0:
                        val += 1000 * v**2
            return val

        t0     = time.perf_counter()
        de_res = differential_evolution(
            _de_obj, bounds, seed=self._de_seed,
            maxiter=300, popsize=12, tol=1e-7, polish=False,
        )
        x_best = de_res.x

        if self._polish:
            cons_scipy = self._cset.slsqp_constraints(initial_params)
            pol = minimize(
                lambda x: self._obj(self._ev.evaluate(self._unpack(x, initial_params))),
                x_best, bounds=bounds, constraints=cons_scipy,
                method="SLSQP", options={"ftol": 1e-10, "maxiter": 400},
            )
            if pol.success and pol.fun < _de_obj(x_best):
                x_best = pol.x

        elapsed    = time.perf_counter() - t0
        opt_params = self._unpack(x_best, initial_params)
        feasible   = self._cset.hard_feasible(x_best, initial_params)
        return OptimResult(
            optimized_params=opt_params,
            results=self._ev.evaluate(opt_params),
            objective_value=float(self._obj(self._ev.evaluate(opt_params))),
            success=bool(de_res.success),
            message=str(de_res.message),
            n_iter=int(de_res.nit),
            elapsed_s=elapsed,
            feasible=feasible,
        )


# =============================================================================
# §8b  PARALLEL MULTI-START WRAPPER
# =============================================================================

class ParallelMultiStartOptimizer:
    """Run multi-start SLSQP concurrently with ``ThreadPoolExecutor``."""

    def __init__(
        self,
        domain_name: str,
        config:      DomainConfig,
        design_vars: List[Tuple[str, Tuple[float, float]]],
        max_workers: Optional[int] = None,
    ) -> None:
        self._domain_name = domain_name
        self._config      = config
        self._dvars       = design_vars
        self._max_workers = max_workers

    def run(
        self,
        start_points: List[np.ndarray],
        base_params:  Dict[str, float],
    ) -> "MultiStartResults":
        from .sampling import MultiStartResults  # local import to avoid circularity
        from .factory  import get_domain

        t_total   = time.perf_counter()
        all_runs: List[Optional[OptimResult]] = [None] * len(start_points)

        def _run_one(args: Tuple[int, np.ndarray]) -> Tuple[int, OptimResult]:
            idx, x0 = args
            domain  = get_domain(self._domain_name, self._config)
            return idx, domain.optimizer.optimize_design(base_params, x0_override=x0)

        if self._max_workers == 1:
            for idx, x0 in enumerate(start_points):
                _, res = _run_one((idx, x0))
                all_runs[idx] = res
        else:
            with ThreadPoolExecutor(max_workers=self._max_workers) as pool:
                futs = {pool.submit(_run_one, (i, x0)): i
                        for i, x0 in enumerate(start_points)}
                for fut in as_completed(futs):
                    try:
                        idx, res = fut.result()
                        all_runs[idx] = res
                    except Exception as exc:
                        log.warning("Parallel start %d failed: %s", futs[fut], exc)

        valid     = [r for r in all_runs if r is not None]
        converged = [r for r in valid if r.success]
        best      = min(converged or valid, key=lambda r: r.objective_value)
        elapsed   = time.perf_counter() - t_total
        return MultiStartResults(
            all_runs=valid, best=best, n_converged=len(converged),
            mode="parallel", n_runs=len(start_points), seed=0,
            total_elapsed_s=elapsed,
        )


# =============================================================================
# §8c  PARETO FRONT OPTIMIZER  (NSGA-II / NSGA-III)
# =============================================================================

@dataclass
class ParetoSolution:
    params:     Dict[str, float]
    objectives: Dict[str, float]
    all_kpis:   Dict[str, float]
    feasible:   bool
    polished:   bool = False


@dataclass
class ParetoFront:
    solutions:      List[ParetoSolution]
    objective_keys: List[str]
    mode:           str
    n_gen:          int
    pop_size:       int
    elapsed_s:      float

    def summary(self) -> str:
        feasible = [s for s in self.solutions if s.feasible]
        lines = [
            f"\n{'='*68}",
            f"  Pareto Front  [{self.mode.upper()}]  "
            f"{len(self.solutions)} solutions  ({len(feasible)} feasible)",
            f"  Objectives: {self.objective_keys}",
            f"  Generations: {self.n_gen}  |  Pop: {self.pop_size}  |  "
            f"Elapsed: {self.elapsed_s:.1f}s",
            f"{'='*68}",
        ]
        if not feasible:
            lines.append("  (no feasible solutions found)")
            return "\n".join(lines)
        for k in self.objective_keys:
            vals = [s.objectives[k] for s in feasible]
            lines.append(f"  {k:<40} min={min(vals):.4g}  max={max(vals):.4g}")
        return "\n".join(lines)

    def best_compromise(self) -> Optional[ParetoSolution]:
        feasible = [s for s in self.solutions if s.feasible]
        if not feasible:
            return None
        arr = np.array([[s.objectives[k] for k in self.objective_keys]
                        for s in feasible])
        lo, hi = arr.min(0), arr.max(0)
        rng  = np.where(hi - lo > 1e-12, hi - lo, 1.0)
        norm = (arr - lo) / rng
        return feasible[int(np.argmin(np.linalg.norm(norm, axis=1)))]

    def to_csv(self, path: Path) -> None:
        with path.open("w", newline="", encoding="utf-8") as fh:
            keys = (list(self.solutions[0].params.keys()) +
                    self.objective_keys + ["feasible", "polished"])
            w = csv.DictWriter(fh, fieldnames=keys)
            w.writeheader()
            for s in self.solutions:
                row = {**s.params,
                       **{k: s.objectives.get(k, "") for k in self.objective_keys},
                       "feasible": s.feasible, "polished": s.polished}
                w.writerow(row)
        log.info("Pareto CSV written to %s", path)

    def to_json(self, path: Path) -> None:
        data = {
            "mode": self.mode, "n_gen": self.n_gen, "pop_size": self.pop_size,
            "elapsed_s": self.elapsed_s, "objective_keys": self.objective_keys,
            "solutions": [{"params": s.params, "objectives": s.objectives,
                           "feasible": s.feasible, "polished": s.polished}
                          for s in self.solutions],
        }
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        log.info("Pareto JSON written to %s", path)


class NSGAParetoOptimizer:
    """Multi-objective NSGA-II / NSGA-III optimizer via pymoo."""

    def __init__(
        self,
        evaluator:      AbstractEvaluator,
        design_vars:    List[Tuple[str, Tuple[float, float]]],
        objective_keys: List[str],
        cset:           ConstraintSet,
        base_params:    Dict[str, float],
        mode:           str  = "nsga2",
        pop_size:       int  = 100,
        n_gen:          int  = 200,
        seed:           int  = 0,
        polish:         bool = False,
        n_workers:      int  = 1,
    ) -> None:
        if not PYMOO_AVAILABLE:
            raise ImportError("pymoo required.  pip install pymoo")
        self._ev       = evaluator
        self._dvars    = design_vars
        self._obj_keys = objective_keys
        self._cset     = cset
        self._base     = base_params
        self._mode     = mode
        self._pop_size = pop_size
        self._n_gen    = n_gen
        self._seed     = seed
        self._polish   = polish
        self._n_workers = n_workers

    def _unpack(self, x: np.ndarray) -> Dict[str, float]:
        p = dict(self._base)
        for i, (n, _) in enumerate(self._dvars):
            p[n] = float(x[i])
        return p

    def _build_problem(self) -> "PymooProblem":
        ev, dvars, obj_keys, cset, base = (
            self._ev, self._dvars, self._obj_keys, self._cset, self._base)
        xl = np.array([b[0] for _, b in dvars])
        xu = np.array([b[1] for _, b in dvars])

        class _Prob(PymooProblem):
            def __init__(inner):
                super().__init__(n_var=len(dvars), n_obj=len(obj_keys),
                                 n_ieq_constr=cset.n_constraints,
                                 xl=xl, xu=xu)

            def _evaluate(inner, X, out, *args, **kwargs):
                F_rows, G_rows = [], []
                for x_row in X:
                    p = dict(base)
                    for i, (n, _) in enumerate(dvars):
                        p[n] = float(x_row[i])
                    try:
                        res = ev.evaluate(p)
                        F_rows.append([float(res.get(k, 0.0)) for k in obj_keys])
                        G_rows.append(list(cset.as_pymoo_G(x_row, base)))
                    except Exception:
                        F_rows.append([1e18] * len(obj_keys))
                        G_rows.append([1.0] * cset.n_constraints)
                out["F"] = np.array(F_rows)
                out["G"] = np.array(G_rows)

        return _Prob()

    def run(self) -> ParetoFront:
        t0      = time.perf_counter()
        problem = self._build_problem()

        if self._mode == "nsga3":
            n_part   = max(4, 12 // max(len(self._obj_keys) - 1, 1))
            ref_dirs = get_reference_directions(
                "das-dennis", len(self._obj_keys), n_partitions=n_part)
            algo = NSGA3(pop_size=self._pop_size, ref_dirs=ref_dirs)
        else:
            algo = NSGA2(pop_size=self._pop_size)

        log.info("Pareto [%s]: pop=%d  gen=%d  obj=%s",
                 self._mode, self._pop_size, self._n_gen, self._obj_keys)

        pymoo_res = pymoo_minimize(
            problem, algo, ("n_gen", self._n_gen),
            seed=self._seed, verbose=False,
        )
        solutions: List[ParetoSolution] = []
        X = pymoo_res.X if pymoo_res.X is not None else np.empty((0, len(self._dvars)))
        F = pymoo_res.F if pymoo_res.F is not None else np.empty((0, len(self._obj_keys)))

        for row_x, row_f in zip(X, F):
            p = self._unpack(row_x)
            try:
                kpis     = self._ev.evaluate(p)
                feasible = self._cset.hard_feasible(row_x, self._base)
            except Exception:
                kpis, feasible = {}, False
            solutions.append(ParetoSolution(
                params=p,
                objectives={k: float(row_f[i]) for i, k in enumerate(self._obj_keys)},
                all_kpis={k: float(v) for k, v in kpis.items()
                          if isinstance(v, (int, float)) and k != "geometry"},
                feasible=feasible,
            ))

        elapsed = time.perf_counter() - t0
        return ParetoFront(
            solutions=solutions, objective_keys=self._obj_keys,
            mode=self._mode, n_gen=self._n_gen,
            pop_size=self._pop_size, elapsed_s=elapsed,
        )



