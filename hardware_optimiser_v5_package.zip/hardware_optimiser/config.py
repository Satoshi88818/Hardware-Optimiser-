"""hardware_optimiser.config — DomainConfig loading."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ._compat import yaml_safe_load, YAML_AVAILABLE


@dataclass
class DomainConfig:
    """
    All user-tunable settings for a single optimisation run.

    Attributes
    ----------
    params:           Fixed / initial parameter overrides.
    bounds:           Design-variable bound overrides  {name: (lo, hi)}.
    weights:          Objective-term weight overrides  {kpi: w}.
    tols:             Tolerance σ as fraction of nominal  {param: frac}.
    mass_models:      Pluggable mass-model spec  {domain: {...}}.
    objectives:       KPI names to use as Pareto objectives.
    constraint_kinds: Per-constraint kind overrides  {name: "soft"|"hard_ineq"|"hard_eq"}.
    doe_size:         LHS DoE size for surrogate / BO initial fit.
    bo_budget:        Total physics evaluations for BayesOpt (DoE + BO).
    surrogate:        Surrogate model type  "gp" | "rbf".
    """

    params:           Dict[str, float]               = field(default_factory=dict)
    bounds:           Dict[str, Tuple[float, float]] = field(default_factory=dict)
    weights:          Dict[str, float]               = field(default_factory=dict)
    tols:             Dict[str, float]               = field(default_factory=dict)
    mass_models:      Dict[str, Any]                 = field(default_factory=dict)
    objectives:       List[str]                      = field(default_factory=list)
    constraint_kinds: Dict[str, str]                 = field(default_factory=dict)
    doe_size:         int                            = 24
    bo_budget:        int                            = 40
    surrogate:        str                            = "gp"

    @classmethod
    def empty(cls) -> "DomainConfig":
        return cls()

    @classmethod
    def from_file(cls, path: str) -> "DomainConfig":
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"Config not found: {path}")

        if p.suffix in (".yaml", ".yml"):
            with p.open() as fh:
                raw: Dict[str, Any] = yaml_safe_load(fh) or {}
        elif p.suffix == ".json":
            with p.open() as fh:
                raw = json.load(fh)
        else:
            raise ValueError(f"Unsupported config format: {p.suffix}")

        def _fdict(section: str) -> Dict[str, float]:
            out: Dict[str, float] = {}
            for k, v in (raw.get(section) or {}).items():
                try:
                    out[str(k)] = float(v)
                except (TypeError, ValueError) as exc:
                    raise ValueError(f"Config {section}['{k}'] must be numeric.") from exc
            return out

        bounds: Dict[str, Tuple[float, float]] = {}
        for k, v in (raw.get("bounds") or {}).items():
            try:
                lo, hi = float(v[0]), float(v[1])
            except Exception as exc:
                raise ValueError(f"Config bounds['{k}'] must be [lo, hi].") from exc
            if lo >= hi:
                raise ValueError(f"Config bounds['{k}']: lo must be < hi.")
            bounds[str(k)] = (lo, hi)

        return cls(
            params=_fdict("params"),
            bounds=bounds,
            weights=_fdict("weights"),
            tols=_fdict("tols"),
            mass_models=raw.get("mass_models") or {},
            objectives=list(raw.get("objectives") or []),
            constraint_kinds={str(k): str(v)
                              for k, v in (raw.get("constraint_kinds") or {}).items()},
            doe_size=int(raw.get("doe_size", 24)),
            bo_budget=int(raw.get("bo_budget", 40)),
            surrogate=str(raw.get("surrogate", "gp")),
        )

    @classmethod
    def from_file_or_empty(cls, path: Optional[str]) -> "DomainConfig":
        return cls.from_file(path) if path is not None else cls.empty()
