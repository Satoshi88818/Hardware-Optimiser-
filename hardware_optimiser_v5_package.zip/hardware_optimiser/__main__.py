"""Enable  python -m hardware_optimiser  as the CLI entry point."""
from .cli import main

if __name__ == "__main__":
    main()
