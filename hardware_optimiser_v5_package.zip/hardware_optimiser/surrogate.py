"""
hardware_optimiser.surrogate
=============================
RBF / GP surrogate wrapper (§8d) and Bayesian Optimisation loop (§8e).

Classes
-------
SurrogateStats       — per-KPI uncertainty statistics dataclass
SurrogateEvaluator   — drop-in AbstractEvaluator backed by GP or RBF
BOResult             — full result of a BO run
BayesianOptimizer    — GP-EI active-learning loop
"""

from __future__ import annotations

import logging
import time
import warnings
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
from scipy.interpolate import RBFInterpolator
from scipy.optimize import minimize
from scipy.stats import norm as _sci_norm
from scipy.stats import qmc

from ._compat import SKLEARN_AVAILABLE, SKGPR, SK_CK, SK_Matern
from .constraints import ConstraintSet
from .interfaces import AbstractEvaluator
from .objective import WeightedObjective

log = logging.getLogger("hardware_optimiser")


# =============================================================================
# §8d  SurrogateStats + SurrogateEvaluator
# =============================================================================

@dataclass
class SurrogateStats:
    """Per-KPI surrogate uncertainty statistics at a single design point."""
    mean:       Dict[str, float]
    std:        Dict[str, float]
    p05:        Dict[str, float]
    p95:        Dict[str, float]
    worst_case: Dict[str, float]   # mean + 2σ  (conservative upper tail)

    def report(self) -> str:
        lines = [
            f"  {'KPI':<32}  {'Mean':>12}  {'Std':>10}  "
            f"{'P05':>12}  {'P95':>12}  {'Worst':>12}",
            "  " + "-" * 84,
        ]
        for k in self.mean:
            lines.append(
                f"  {k:<32}  {self.mean[k]:>12.5g}  {self.std[k]:>10.4g}"
                f"  {self.p05[k]:>12.5g}  {self.p95[k]:>12.5g}"
                f"  {self.worst_case[k]:>12.5g}"
            )
        return "\n".join(lines)


class SurrogateEvaluator(AbstractEvaluator):
    """
    Wraps a physics ``AbstractEvaluator`` with a fitted GP or RBF surrogate.

    Workflow
    --------
    1. ``fit(n_doe, base_params, seed)``
       Samples *n_doe* LHS points, evaluates physics, fits the surrogate.
    2. ``evaluate(params)``
       Returns surrogate mean prediction as the KPI dict (drop-in replacement).
    3. ``predict_with_uncertainty(x_raw)``
       Returns ``(μ, σ)`` arrays of shape *(n_kpi,)*.
    4. ``stats_at(params)``
       Returns a full :class:`SurrogateStats` at the given point.
    5. ``update(params, kpis)``
       Appends one observation and refits (active learning, used by BO loop).

    The surrogate operates in normalised ``[0,1]^d`` input space.
    Each KPI output is independently standardised (zero-mean, unit-variance).
    """

    #: σ multiplier for worst-case estimate  (2σ ≈ 95th percentile).
    WORST_CASE_SIGMA_K: float = 2.0

    def __init__(
        self,
        physics_ev:  AbstractEvaluator,
        design_vars: List[Tuple[str, Tuple[float, float]]],
        model_type:  str = "gp",                    # "gp" | "rbf"
        rbf_kernel:  str = "thin_plate_spline",
        gp_restarts: int = 3,
    ) -> None:
        if model_type == "gp" and not SKLEARN_AVAILABLE:
            raise ImportError(
                "scikit-learn required for GP surrogate.  pip install scikit-learn"
            )
        self._physics     = physics_ev
        self._dvars       = design_vars
        self._model_type  = model_type
        self._rbf_kernel  = rbf_kernel
        self._gp_restarts = gp_restarts
        self._dvar_names  = [n for n, _ in design_vars]
        self._n           = len(design_vars)
        self._lo          = np.array([b[0] for _, b in design_vars])
        self._hi          = np.array([b[1] for _, b in design_vars])

        self._X_raw: Optional[np.ndarray] = None
        self._Y_raw: Optional[np.ndarray] = None
        self._kpi_keys: List[str]          = []
        self._models:   List[Any]          = []
        self._y_mean:   np.ndarray         = np.zeros(0)
        self._y_std:    np.ndarray         = np.ones(0)
        self._fitted    = False

    # ── AbstractEvaluator protocol ────────────────────────────────────────────

    @property
    def tolerance_params(self) -> List[str]:
        return self._physics.tolerance_params

    def evaluate(self, params: Dict[str, float]) -> Dict[str, Any]:
        """Return surrogate mean as KPI dict (transparent fallback before fit)."""
        if not self._fitted:
            return self._physics.evaluate(params)
        x_raw = np.array([params.get(n, 0.0) for n in self._dvar_names])
        mu, _ = self.predict_with_uncertainty(x_raw)
        return {k: float(mu[i]) for i, k in enumerate(self._kpi_keys)}

    # ── Fitting / updating ────────────────────────────────────────────────────

    def fit(self, n_doe: int, base_params: Dict[str, float], seed: int = 0) -> None:
        """Sample *n_doe* LHS points, evaluate physics, fit surrogate from scratch."""
        pts_unit = qmc.LatinHypercube(d=self._n, seed=seed).random(n=n_doe)
        pts_raw  = self._lo + pts_unit * (self._hi - self._lo)

        rows: List[Dict[str, float]] = []
        for row in pts_raw:
            p = dict(base_params)
            for i, name in enumerate(self._dvar_names):
                p[name] = float(row[i])
            try:
                res = self._physics.evaluate(p)
                rows.append({k: float(v) for k, v in res.items()
                             if isinstance(v, (int, float)) and k != "geometry"})
            except Exception as exc:
                log.debug("DoE eval failed: %s", exc)

        if not rows:
            raise RuntimeError("Surrogate fit: DoE produced no valid evaluations.")

        self._kpi_keys = [k for k in rows[0] if not k.startswith("__")]
        self._X_raw    = pts_raw[: len(rows)]
        self._Y_raw    = np.array(
            [[r.get(k, float("nan")) for k in self._kpi_keys] for r in rows]
        )
        self._refit()

    def update(self, params: Dict[str, float], results: Dict[str, float]) -> None:
        """Append one physics observation and refit (active-learning hook)."""
        if self._X_raw is None:
            raise RuntimeError("Call .fit() before .update().")
        x_new = np.array([[params.get(n, 0.0) for n in self._dvar_names]])
        y_new = np.array([[results.get(k, float("nan")) for k in self._kpi_keys]])
        self._X_raw = np.vstack([self._X_raw, x_new])
        self._Y_raw = np.vstack([self._Y_raw, y_new])
        self._refit()

    def _refit(self) -> None:
        assert self._X_raw is not None and self._Y_raw is not None
        X_norm       = self._normalise_x(self._X_raw)
        self._y_mean = np.nanmean(self._Y_raw, axis=0)
        self._y_std  = np.where(
            np.nanstd(self._Y_raw, axis=0) > 1e-12,
            np.nanstd(self._Y_raw, axis=0), 1.0,
        )
        Y_norm = (self._Y_raw - self._y_mean) / self._y_std

        self._models = []
        for j in range(len(self._kpi_keys)):
            mask = ~np.isnan(Y_norm[:, j])
            if mask.sum() < 3:
                self._models.append(None)
                continue
            if self._model_type == "gp":
                m = self._build_gp()
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    m.fit(X_norm[mask], Y_norm[mask, j])
            else:
                m = RBFInterpolator(
                    X_norm[mask], Y_norm[mask, j],
                    kernel=self._rbf_kernel, smoothing=0.01,
                )
            self._models.append(m)

        self._fitted = True
        log.debug("Surrogate refit: %d pts, %d KPIs, model=%s",
                  len(self._X_raw), len(self._kpi_keys), self._model_type)

    def _build_gp(self) -> "SKGPR":
        kernel = SK_CK(1.0, constant_value_bounds=(1e-3, 1e3)) * SK_Matern(
            length_scale=np.ones(self._n),
            length_scale_bounds=[(1e-2, 10.0)] * self._n,
            nu=2.5,
        )
        return SKGPR(
            kernel=kernel,
            n_restarts_optimizer=self._gp_restarts,
            normalize_y=True,
            alpha=1e-6,
        )

    # ── Prediction ────────────────────────────────────────────────────────────

    def _normalise_x(self, x_raw: np.ndarray) -> np.ndarray:
        rng = np.where(self._hi - self._lo > 1e-12, self._hi - self._lo, 1.0)
        return (x_raw - self._lo) / rng

    def predict_with_uncertainty(
        self, x_raw: np.ndarray
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Return *(μ, σ)* arrays of shape *(n_kpi,)* in original KPI units.

        For RBF surrogates *σ* is estimated from residuals on training data.
        """
        if not self._fitted:
            raise RuntimeError("Call .fit() first.")
        x_norm   = self._normalise_x(x_raw.reshape(1, -1))
        mu_norm  = np.zeros(len(self._kpi_keys))
        std_norm = np.zeros(len(self._kpi_keys))

        for j, m in enumerate(self._models):
            if m is None:
                continue
            if self._model_type == "gp":
                mu_j, s_j   = m.predict(x_norm, return_std=True)
                mu_norm[j]  = float(mu_j[0])
                std_norm[j] = float(s_j[0])
            else:
                mu_norm[j] = float(m(x_norm)[0])
                y_pred_tr  = m(self._normalise_x(self._X_raw))
                Y_norm_j   = (self._Y_raw[:, j] - self._y_mean[j]) / self._y_std[j]
                std_norm[j] = float(np.std(y_pred_tr - Y_norm_j)) + 1e-8

        mu  = mu_norm  * self._y_std + self._y_mean
        std = std_norm * self._y_std
        return mu, std

    def stats_at(self, params: Dict[str, float]) -> SurrogateStats:
        """Return full uncertainty statistics at a single design point."""
        x_raw   = np.array([params.get(n, 0.0) for n in self._dvar_names])
        mu, std = self.predict_with_uncertainty(x_raw)
        p05   = mu - 1.645 * std
        p95   = mu + 1.645 * std
        worst = mu + self.WORST_CASE_SIGMA_K * std
        return SurrogateStats(
            mean      ={k: float(mu[i])    for i, k in enumerate(self._kpi_keys)},
            std       ={k: float(std[i])   for i, k in enumerate(self._kpi_keys)},
            p05       ={k: float(p05[i])   for i, k in enumerate(self._kpi_keys)},
            p95       ={k: float(p95[i])   for i, k in enumerate(self._kpi_keys)},
            worst_case={k: float(worst[i]) for i, k in enumerate(self._kpi_keys)},
        )

    # ── Convenience properties ────────────────────────────────────────────────

    @property
    def n_training_points(self) -> int:
        return 0 if self._X_raw is None else len(self._X_raw)

    def physics_evaluator(self) -> AbstractEvaluator:
        return self._physics


# =============================================================================
# §8e  BOResult + BayesianOptimizer
# =============================================================================

@dataclass
class BOResult:
    """Full result of a Bayesian Optimisation run."""
    best_params:       Dict[str, float]
    best_results:      Dict[str, float]
    best_obj:          float
    feasible:          bool
    n_total_evals:     int
    doe_size:          int
    elapsed_s:         float
    surrogate_stats:   SurrogateStats
    acquisition_trace: List[float]   # EI value at each BO iteration
    obj_trace:         List[float]   # best objective seen so far per iteration

    def report(self) -> str:
        lines = [
            "=" * 68,
            "  Bayesian Optimisation result",
            f"  Total physics evaluations : {self.n_total_evals}  "
            f"(DoE={self.doe_size}  BO={self.n_total_evals - self.doe_size})",
            f"  Best objective value      : {self.best_obj:.6g}",
            f"  Feasible                  : {self.feasible}",
            f"  Elapsed                   : {self.elapsed_s:.2f}s",
            "=" * 68,
            "",
            "  Optimised design variables:",
        ]
        for k, v in self.best_params.items():
            if isinstance(v, (int, float)):
                lines.append(f"    {k:<36} = {v:.6g}")
        lines.append("")
        lines.append("  Surrogate statistics at optimum:")
        lines.append(self.surrogate_stats.report())
        return "\n".join(lines)


class BayesianOptimizer:
    """
    GP-EI Bayesian Optimisation loop.

    Algorithm
    ---------
    1. Fit surrogate on LHS DoE.
    2. Maximise Expected Improvement (multi-start L-BFGS-B) → next candidate.
    3. Evaluate true physics at candidate.
    4. Append observation, refit surrogate.
    5. Repeat until *bo_budget* total evaluations reached.
    6. Return best-observed point with full surrogate uncertainty statistics.
    """

    def __init__(
        self,
        physics_ev:  AbstractEvaluator,
        surrogate:   SurrogateEvaluator,
        objective:   WeightedObjective,
        design_vars: List[Tuple[str, Tuple[float, float]]],
        cset:        ConstraintSet,
        base_params: Dict[str, float],
        bo_budget:   int = 40,
        doe_size:    int = 24,
        seed:        int = 0,
        ei_restarts: int = 8,
    ) -> None:
        self._physics     = physics_ev
        self._surrogate   = surrogate
        self._obj         = objective
        self._dvars       = design_vars
        self._cset        = cset
        self._base        = base_params
        self._budget      = bo_budget
        self._doe_size    = doe_size
        self._seed        = seed
        self._ei_restarts = ei_restarts
        self._dvar_names  = [n for n, _ in design_vars]
        self._lo = np.array([b[0] for _, b in design_vars])
        self._hi = np.array([b[1] for _, b in design_vars])

    def _unpack(self, x: np.ndarray) -> Dict[str, float]:
        p = dict(self._base)
        for i, n in enumerate(self._dvar_names):
            p[n] = float(x[i])
        return p

    def _expected_improvement(self, x: np.ndarray, y_best: float) -> float:
        """
        Negative EI (for minimisation by scipy).

        EI(x) = σ(x)·[z·Φ(z) + φ(z)]   where z = (y_best − μ(x)) / σ(x).
        """
        mu_kpi, std_kpi = self._surrogate.predict_with_uncertainty(x)
        kpi_dict  = {k: float(mu_kpi[i])
                     for i, k in enumerate(self._surrogate._kpi_keys)}
        mu_obj    = float(self._obj(kpi_dict))
        sigma_obj = float(np.sqrt(np.sum(std_kpi**2))) + 1e-9
        z  = (y_best - mu_obj) / sigma_obj
        ei = sigma_obj * (z * _sci_norm.cdf(z) + _sci_norm.pdf(z))
        return -ei

    def _maximise_ei(self, y_best: float) -> np.ndarray:
        bounds = list(zip(self._lo, self._hi))
        rng    = np.random.default_rng(self._seed)
        starts = self._lo + rng.random((self._ei_restarts, len(self._dvars))) * (
            self._hi - self._lo
        )
        best_x, best_neg_ei = starts[0], np.inf

        for x0 in starts:
            res = minimize(
                lambda x: self._expected_improvement(x, y_best),
                x0, bounds=bounds, method="L-BFGS-B",
                options={"ftol": 1e-9, "maxiter": 100},
            )
            if res.fun < best_neg_ei:
                best_neg_ei = res.fun
                best_x      = res.x
        return best_x

    def run(self) -> BOResult:
        t0 = time.perf_counter()
        log.info("BayesianOptimizer: DoE=%d  budget=%d  model=%s",
                 self._doe_size, self._budget, self._surrogate._model_type)

        self._surrogate.fit(self._doe_size, self._base, seed=self._seed)

        obs_params: List[Dict[str, float]] = []
        obs_obj:    List[float]            = []
        obs_kpis:   List[Dict[str, float]] = []

        for i in range(self._surrogate.n_training_points):
            x_raw = self._surrogate._X_raw[i]
            p     = self._unpack(x_raw)
            try:
                kpis = self._physics.evaluate(p)
                ks   = {k: float(v) for k, v in kpis.items()
                        if isinstance(v, (int, float)) and k != "geometry"}
                obs_params.append(p)
                obs_obj.append(float(self._obj(ks)))
                obs_kpis.append(ks)
            except Exception:
                pass

        acquisition_trace: List[float] = []
        obj_trace: List[float] = [
            obs_obj[int(np.argmin(obs_obj))] if obs_obj else float("inf")
        ]

        n_bo = self._budget - self._doe_size
        for iteration in range(n_bo):
            y_best = min(obs_obj) if obs_obj else 0.0
            x_next = self._maximise_ei(y_best)
            ei_val = -self._expected_improvement(x_next, y_best)
            acquisition_trace.append(float(ei_val))

            p_next = self._unpack(x_next)
            try:
                kpis_next = self._physics.evaluate(p_next)
                ks_next   = {k: float(v) for k, v in kpis_next.items()
                             if isinstance(v, (int, float)) and k != "geometry"}
                obj_next  = float(self._obj(ks_next))
            except Exception as exc:
                log.debug("BO physics eval failed iter %d: %s", iteration, exc)
                ks_next, obj_next = {}, float("inf")

            obs_params.append(p_next)
            obs_obj.append(obj_next)
            obs_kpis.append(ks_next)

            try:
                self._surrogate.update(p_next, ks_next)
            except Exception as exc:
                log.debug("Surrogate update failed: %s", exc)

            best_so_far = min(obs_obj)
            obj_trace.append(best_so_far)
            log.info("BO iter %3d/%d  EI=%.4g  new_obj=%.5g  best=%.5g",
                     iteration + 1, n_bo, ei_val, obj_next, best_so_far)

        best_idx    = int(np.argmin(obs_obj))
        best_params = obs_params[best_idx]
        best_kpis   = obs_kpis[best_idx]
        best_obj    = obs_obj[best_idx]
        x_best      = np.array([best_params.get(n, 0.0) for n in self._dvar_names])
        feasible    = self._cset.hard_feasible(x_best, self._base)
        stats       = self._surrogate.stats_at(best_params)
        elapsed     = time.perf_counter() - t0

        return BOResult(
            best_params=best_params,
            best_results=best_kpis,
            best_obj=best_obj,
            feasible=feasible,
            n_total_evals=len(obs_params),
            doe_size=self._doe_size,
            elapsed_s=elapsed,
            surrogate_stats=stats,
            acquisition_trace=acquisition_trace,
            obj_trace=obj_trace,
        )
