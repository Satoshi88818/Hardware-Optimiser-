"""
hardware_optimiser
==================
Abstract, domain-agnostic hardware design optimiser — v5 package.

Quick start
-----------
>>> from hardware_optimiser import get_domain, DomainConfig
>>> domain = get_domain("nozzle", DomainConfig.empty())
>>> result = domain.optimizer.optimize_design(domain.effective_params())
>>> print(result.scalar_results())

CLI entry point
---------------
    python -m hardware_optimiser --domain nozzle --mode single
    python -m hardware_optimiser --test
    python -m hardware_optimiser --dashboard
"""

from .config      import DomainConfig
from .constraints import (
    ClassifiedConstraint,
    ConstraintKind,
    ConstraintSet,
    ConstraintSpec,
    build_constraint_set,
)
from .autodiff    import GradientBackend, JaxGradientProvider, make_jax_objective
from .dataclasses_ import (
    MotorParams, MotorResults,
    NozzleParams, NozzleResults,
    PumpParams,   PumpResults,
)
from .factory     import (
    _DOMAIN_MAP,
    get_bo_optimizer,
    get_domain,
    get_feasibility_repair,
    get_optimizer,
    get_pareto_optimizer,
    get_surrogate,
)
from .interfaces  import (
    AbstractAxioms,
    AbstractConstraints,
    AbstractEvaluator,
    AbstractGeometryExporter,
    AbstractGeometryGenerator,
    AbstractOptimizer,
    AbstractSimulator,
    HardwareDomain,
    OptimResult,
)
from .objective   import ObjectiveTerm, WeightedObjective
from .optimizers  import (
    DifferentialEvolutionOptimizer,
    FeasibilityRepair,
    GenericOptimizer,
    NSGAParetoOptimizer,
    ParetoFront,
    ParetoSolution,
    ParallelMultiStartOptimizer,
    ParallelSLSQPEvaluator,
)
from .registry    import PhysicsRegistry
from .runner      import (
    run_bayesopt,
    run_differential_evo,
    run_pareto,
    run_sampling,
    run_single,
    run_surrogate_single,
    run_tolerance_study,
)
from .sampling    import MultiStartResults, run_multistart
from .surrogate   import (
    BOResult,
    BayesianOptimizer,
    SurrogateEvaluator,
    SurrogateStats,
)
from .tolerance   import (
    MassModelRegistry,
    SurrogateTolMCResults,
    ToleranceMCResults,
    run_surrogate_tolerance_mc,
    run_tolerance_mc,
)

# Domain classes (for isinstance checks / type annotations)
from .domains.nozzle           import NozzleDomain
from .domains.electric_motor   import ElectricMotorDomain
from .domains.centrifugal_pump import CentrifugalPumpDomain

__version__ = "5.0.0"
__all__ = [
    # config
    "DomainConfig",
    # constraints
    "ClassifiedConstraint", "ConstraintKind", "ConstraintSet",
    "ConstraintSpec", "build_constraint_set",
    # autodiff
    "GradientBackend", "JaxGradientProvider", "make_jax_objective",
    # dataclasses
    "MotorParams", "MotorResults",
    "NozzleParams", "NozzleResults",
    "PumpParams", "PumpResults",
    # factory
    "_DOMAIN_MAP",
    "get_bo_optimizer", "get_domain", "get_feasibility_repair",
    "get_optimizer", "get_pareto_optimizer", "get_surrogate",
    # interfaces
    "AbstractAxioms", "AbstractConstraints", "AbstractEvaluator",
    "AbstractGeometryExporter", "AbstractGeometryGenerator",
    "AbstractOptimizer", "AbstractSimulator",
    "HardwareDomain", "OptimResult",
    # objective
    "ObjectiveTerm", "WeightedObjective",
    # optimizers
    "DifferentialEvolutionOptimizer", "FeasibilityRepair", "GenericOptimizer",
    "NSGAParetoOptimizer", "ParetoFront", "ParetoSolution",
    "ParallelMultiStartOptimizer", "ParallelSLSQPEvaluator",
    # registry
    "PhysicsRegistry",
    # runner
    "run_bayesopt", "run_differential_evo", "run_pareto",
    "run_sampling", "run_single", "run_surrogate_single", "run_tolerance_study",
    # sampling
    "MultiStartResults", "run_multistart",
    # surrogate
    "BOResult", "BayesianOptimizer", "SurrogateEvaluator", "SurrogateStats",
    # tolerance
    "MassModelRegistry", "SurrogateTolMCResults",
    "ToleranceMCResults", "run_surrogate_tolerance_mc", "run_tolerance_mc",
    # domain classes
    "NozzleDomain", "ElectricMotorDomain", "CentrifugalPumpDomain",
]
