"""
hardware_optimiser.tolerance
=============================
Manufacturing tolerance Monte-Carlo (§10), pluggable mass-model registry (§10b),
and surrogate-aware tolerance MC (§10c).
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np

from .interfaces import AbstractEvaluator

log = logging.getLogger("hardware_optimiser")


# =============================================================================
# §10  MANUFACTURING TOLERANCE MONTE-CARLO
# =============================================================================

@dataclass
class ToleranceMCResults:
    n_samples:  int
    pass_rate:  float
    kpi_mean:   Dict[str, float]
    kpi_std:    Dict[str, float]
    kpi_p05:    Dict[str, float]
    kpi_p95:    Dict[str, float]
    tols_used:  Dict[str, float]
    elapsed_s:  float

    def report(self) -> str:
        lines = [
            f"  Tolerance MC  ({self.n_samples} samples)",
            f"  Pass rate  = {self.pass_rate * 100:.1f} %",
            f"  {'KPI':<30}  {'Mean':>12}  {'Std':>10}  {'P05':>12}  {'P95':>12}",
            "  " + "-" * 70,
        ]
        for k in self.kpi_mean:
            lines.append(
                f"  {k:<30}  {self.kpi_mean[k]:>12.5g}  {self.kpi_std[k]:>10.4g}"
                f"  {self.kpi_p05[k]:>12.5g}  {self.kpi_p95[k]:>12.5g}"
            )
        lines.append(f"\n  Elapsed: {self.elapsed_s:.2f}s")
        return "\n".join(lines)

    def as_dict(self) -> Dict[str, Any]:
        rows = [
            {
                "KPI": k,
                "Mean": self.kpi_mean[k],
                "Std":  self.kpi_std[k],
                "P05":  self.kpi_p05[k],
                "P95":  self.kpi_p95[k],
            }
            for k in self.kpi_mean
        ]
        return {"pass_rate": self.pass_rate, "n_samples": self.n_samples, "kpis": rows}


def run_tolerance_mc(
    best_params:      Dict[str, float],
    evaluator:        AbstractEvaluator,
    constraint_funcs: List[Callable[[np.ndarray, Dict[str, float]], float]],
    design_vars:      List[Tuple[str, Tuple[float, float]]],
    tols:             Dict[str, float],
    n_samples:        int,
    seed:             int,
) -> ToleranceMCResults:
    """
    Perturb *best_params* with Gaussian noise scaled by *tols*, evaluate
    *evaluator*, and report per-KPI statistics and pass rate.

    Parameters
    ----------
    best_params:      Nominal design point.
    evaluator:        Physics or surrogate evaluator.
    constraint_funcs: List of  g(x, base) ≥ 0  callables for pass/fail check.
    design_vars:      Design variable bounds (used to clamp perturbed values).
    tols:             ``{param: sigma_fraction}``  (σ = fraction × nominal value).
    n_samples:        Number of Monte-Carlo samples.
    seed:             RNG seed.
    """
    rng           = np.random.default_rng(seed)
    tol_names     = list(tols.keys())
    tol_sigmas    = np.array([abs(best_params.get(k, 1.0)) * tols[k] for k in tol_names])
    dvar_names    = [n for n, _ in design_vars]
    x_best        = np.array([best_params.get(n, 0.0) for n in dvar_names])
    perturbs      = rng.normal(0.0, tol_sigmas, size=(n_samples, len(tol_names)))
    dvar_bound_map = dict(design_vars)

    all_scalar: List[Dict[str, float]] = []
    n_pass = 0
    t0     = time.perf_counter()

    for delta in perturbs:
        p = dict(best_params)
        for i, name in enumerate(tol_names):
            raw = best_params.get(name, 0.0) + delta[i]
            if name in dvar_bound_map:
                lo, hi = dvar_bound_map[name]
                raw = max(lo, min(hi, raw))
            p[name] = raw
        try:
            res      = evaluator.evaluate(p)
            feasible = all(f(x_best, p) >= -1e-6 for f in constraint_funcs)
            if feasible:
                n_pass += 1
            all_scalar.append(
                {k: float(v) for k, v in res.items()
                 if isinstance(v, (int, float)) and k != "geometry"}
            )
        except Exception:
            pass

    elapsed = time.perf_counter() - t0
    if not all_scalar:
        raise RuntimeError("Tolerance MC: no valid samples produced.")

    keys = list(all_scalar[0].keys())
    arr  = np.array([[s.get(k, float("nan")) for k in keys] for s in all_scalar])
    return ToleranceMCResults(
        n_samples=n_samples,
        pass_rate=n_pass / max(len(all_scalar), 1),
        kpi_mean={k: float(np.nanmean(arr[:, i]))            for i, k in enumerate(keys)},
        kpi_std ={k: float(np.nanstd(arr[:, i]))             for i, k in enumerate(keys)},
        kpi_p05 ={k: float(np.nanpercentile(arr[:, i],  5))  for i, k in enumerate(keys)},
        kpi_p95 ={k: float(np.nanpercentile(arr[:, i], 95))  for i, k in enumerate(keys)},
        tols_used=dict(tols),
        elapsed_s=elapsed,
    )


# =============================================================================
# §10b  PLUGGABLE MASS-MODEL REGISTRY
# =============================================================================

class MassModelRegistry:
    """
    Override a domain's default mass calculation from JSON / config.

    Supported ``model_type`` values:

    ``"constant"``
        ``{ "value_kg": 12.5 }``
    ``"table"``
        ``{ "x_key": "throat_radius", "x": [...], "mass_kg": [...] }``
        (piecewise-linear interpolation)
    ``"regression"``
        ``{ "coeffs": [a0, a1, ...], "input_keys": ["k1", ...] }``
        ``mass = a0 + a1·k1 + ...``
    """

    def __init__(self, domain_name: str, mass_models_cfg: Dict[str, Any]) -> None:
        self._cfg = mass_models_cfg.get(domain_name, {})

    def has_override(self) -> bool:
        return bool(self._cfg)

    def calculate(
        self,
        params:      Dict[str, float],
        fallback_fn: Callable[[Dict[str, float]], float],
    ) -> float:
        if not self.has_override():
            return fallback_fn(params)
        mt = self._cfg.get("model_type", "constant")
        if mt == "constant":
            return float(self._cfg["value_kg"])
        elif mt == "table":
            xs  = np.array(self._cfg["x"],       dtype=float)
            ms  = np.array(self._cfg["mass_kg"],  dtype=float)
            xv  = params.get(self._cfg["x_key"],  xs[0])
            return float(np.interp(xv, xs, ms))
        elif mt == "regression":
            c, keys = self._cfg["coeffs"], self._cfg["input_keys"]
            vals    = [params.get(k, 0.0) for k in keys]
            return float(sum(a * v for a, v in zip(c[1:], vals)) + c[0])
        else:
            log.warning("MassModelRegistry: unknown model_type '%s'; using fallback.", mt)
            return fallback_fn(params)


# =============================================================================
# §10c  SURROGATE-AWARE TOLERANCE MC
# =============================================================================

@dataclass
class SurrogateTolMCResults:
    """
    Combines the Monte-Carlo P05/P95 pass-rate statistics with the
    GP posterior worst-case / mean / std at the nominal design point.
    """
    mc:              ToleranceMCResults
    surrogate_stats: "SurrogateStats"   # forward ref; import at call site

    def report(self) -> str:
        lines = [
            self.mc.report(),
            "",
            "  Surrogate uncertainty at nominal design:",
            self.surrogate_stats.report(),
        ]
        return "\n".join(lines)


def run_surrogate_tolerance_mc(
    best_params:      Dict[str, float],
    surrogate:        Any,              # SurrogateEvaluator
    constraint_funcs: List[Callable[[np.ndarray, Dict[str, float]], float]],
    design_vars:      List[Tuple[str, Tuple[float, float]]],
    tols:             Dict[str, float],
    n_samples:        int,
    seed:             int,
) -> SurrogateTolMCResults:
    """
    Run tolerance MC through the surrogate (fast), then add GP uncertainty stats.

    The surrogate replaces the physics evaluator — thousands of samples in
    milliseconds.  The GP posterior at the nominal point provides additional
    worst-case / mean / std estimates independent of the perturbation spread.
    """
    mc_result = run_tolerance_mc(
        best_params, surrogate, constraint_funcs,
        design_vars, tols, n_samples, seed,
    )
    stats = surrogate.stats_at(best_params)
    return SurrogateTolMCResults(mc=mc_result, surrogate_stats=stats)
