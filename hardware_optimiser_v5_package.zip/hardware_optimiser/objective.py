"""hardware_optimiser.objective — normalised weighted objective framework."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class ObjectiveTerm:
    """Single term in a weighted objective function."""
    kpi_key:    str
    weight:     float
    nominal:    float                        = 1.0
    constraint: Optional[Tuple[str, float]] = None  # ("ge"|"le", bound)
    penalty_k:  float                        = 100.0


class WeightedObjective:
    """
    Normalised weighted scalar objective with optional soft-constraint penalties.

    Contribution of term i:
        w_i * (result[kpi_i] - nominal_i) / |nominal_i|

    Soft-constraint penalty when violated:
        penalty_k * |violation / bound|
    """

    def __init__(
        self,
        terms: List[ObjectiveTerm],
        weight_overrides: Dict[str, float],
    ) -> None:
        self._terms: List[ObjectiveTerm] = []
        for t in terms:
            w = weight_overrides.get(t.kpi_key, t.weight)
            self._terms.append(
                ObjectiveTerm(t.kpi_key, w, t.nominal, t.constraint, t.penalty_k)
            )

    def __call__(self, results: Dict[str, Any]) -> float:
        total = 0.0
        for t in self._terms:
            val   = results.get(t.kpi_key, 0.0)
            denom = abs(t.nominal) if t.nominal != 0.0 else 1.0
            total += t.weight * (val - t.nominal) / denom
            if t.constraint is not None:
                sense, bound = t.constraint
                denom_c = abs(bound) if bound != 0.0 else 1.0
                if sense == "ge" and val < bound:
                    total += t.penalty_k * (bound - val) / denom_c
                elif sense == "le" and val > bound:
                    total += t.penalty_k * (val - bound) / denom_c
        return total

    @property
    def terms(self) -> List[ObjectiveTerm]:
        return list(self._terms)
