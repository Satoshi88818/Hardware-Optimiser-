"""
hardware_optimiser._compat
==========================
Optional-dependency detection and lazy imports.

All other modules import availability flags and objects from here so
that the guard logic lives in exactly one place.
"""

from __future__ import annotations

import logging
import os

log = logging.getLogger("hardware_optimiser")

# ── PyYAML ────────────────────────────────────────────────────────────────────
try:
    import yaml as _yaml
    YAML_AVAILABLE = True
except ImportError:
    _yaml = None            # type: ignore[assignment]
    YAML_AVAILABLE = False

def yaml_safe_load(fh):  # type: ignore[return]
    if not YAML_AVAILABLE:
        raise ImportError("PyYAML required.  pip install pyyaml")
    return _yaml.safe_load(fh)

# ── JAX ───────────────────────────────────────────────────────────────────────
os.environ.setdefault("JAX_PLATFORM_NAME", "cpu")
os.environ.setdefault("JAX_ENABLE_X64",    "1")

try:
    import jax as _jax
    import jax.numpy as jnp
    from jax import grad   as _jax_grad
    from jax import jit    as _jax_jit
    from jax import vmap   as _jax_vmap      # noqa: F401  (re-exported for domains)
    from jax import jacfwd as _jax_jacfwd    # noqa: F401
    _jax.config.update("jax_enable_x64", True)
    JAX_AVAILABLE = True
except Exception:
    _jax        = None          # type: ignore[assignment]
    jnp         = None          # type: ignore[assignment]
    _jax_grad   = None          # type: ignore[assignment]
    _jax_jit    = None          # type: ignore[assignment]
    _jax_vmap   = None          # type: ignore[assignment]
    _jax_jacfwd = None          # type: ignore[assignment]
    JAX_AVAILABLE = False

# ── scikit-learn GP ───────────────────────────────────────────────────────────
try:
    from sklearn.gaussian_process import GaussianProcessRegressor as SKGPR
    from sklearn.gaussian_process.kernels import (
        ConstantKernel as SK_CK,
        Matern         as SK_Matern,
    )
    SKLEARN_AVAILABLE = True
except ImportError:
    SKGPR          = None   # type: ignore[assignment, misc]
    SK_CK          = None   # type: ignore[assignment, misc]
    SK_Matern      = None   # type: ignore[assignment, misc]
    SKLEARN_AVAILABLE = False

# ── pymoo ─────────────────────────────────────────────────────────────────────
try:
    from pymoo.algorithms.moo.nsga2 import NSGA2
    from pymoo.algorithms.moo.nsga3 import NSGA3
    from pymoo.core.problem          import Problem as PymooProblem
    from pymoo.optimize              import minimize as pymoo_minimize
    from pymoo.util.ref_dirs         import get_reference_directions
    PYMOO_AVAILABLE = True
except ImportError:
    NSGA2                  = None   # type: ignore[assignment, misc]
    NSGA3                  = None   # type: ignore[assignment, misc]
    PymooProblem           = None   # type: ignore[assignment, misc]
    pymoo_minimize         = None   # type: ignore[assignment, misc]
    get_reference_directions = None # type: ignore[assignment]
    PYMOO_AVAILABLE = False

# ── SharedMemory ──────────────────────────────────────────────────────────────
try:
    from multiprocessing import shared_memory as _shm
    SHM_AVAILABLE = True
except ImportError:
    _shm          = None   # type: ignore[assignment]
    SHM_AVAILABLE = False
