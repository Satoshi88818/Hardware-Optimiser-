"""hardware_optimiser.cli — argparse CLI entry point (§17)."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path
from typing import List, Optional

import numpy as np

from .config  import DomainConfig
from .factory import (
    _DOMAIN_MAP,
    get_bo_optimizer,
    get_domain,
    get_feasibility_repair,
    get_optimizer,
    get_pareto_optimizer,
    get_surrogate,
)
from .runner  import (
    _export_cad,
    run_bayesopt,
    run_differential_evo,
    run_pareto,
    run_sampling,
    run_single,
    run_surrogate_single,
    run_tolerance_study,
)
from .tests   import _run_tests
from .dashboard import _launch_dashboard

log = logging.getLogger("hardware_optimiser")


def main(argv: Optional[List[str]] = None) -> None:
    parser = argparse.ArgumentParser(
        description="Abstract Hardware Design Optimiser  v5",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python -m hardware_optimiser --domain nozzle\n"
            "  python -m hardware_optimiser --domain electric_motor --mode bayesopt --bo-budget 50\n"
            "  python -m hardware_optimiser --domain nozzle --mode surrogate_single\n"
            "  python -m hardware_optimiser --domain nozzle --mode nsga2 --pop-size 80 --n-gen 150\n"
            "  python -m hardware_optimiser --domain centrifugal_pump --surrogate-stats\n"
            "  python -m hardware_optimiser --domain nozzle --surrogate-tol-mc 5000\n"
            "  python -m hardware_optimiser --domain nozzle --export-cad openscad\n"
            "  python -m hardware_optimiser --domain nozzle --show-constraints\n"
            "  python -m hardware_optimiser --test\n"
            "  python -m hardware_optimiser --dashboard\n"
        ),
    )
    parser.add_argument("--domain",   default="electric_motor",
                        choices=list(_DOMAIN_MAP))
    parser.add_argument("--mode",     default="single",
                        choices=["single","monte_carlo","sobol","differential_evo",
                                 "nsga2","nsga3","bayesopt","surrogate_single"])
    parser.add_argument("--n-runs",   type=int, default=32,
                        help="Multi-start runs (monte_carlo / sobol).")
    parser.add_argument("--seed",     type=int, default=0)
    parser.add_argument("--config",   default=None, metavar="FILE",
                        help="JSON or YAML config file.")
    parser.add_argument("--tolerance-mc",     type=int, default=0, metavar="N",
                        help="Physics tolerance MC samples (0 = off).")
    parser.add_argument("--surrogate-tol-mc", type=int, default=0, metavar="N",
                        help="Surrogate tolerance MC samples (0 = off).")
    parser.add_argument("--surrogate-stats",  action="store_true",
                        help="Print surrogate uncertainty stats at optimum.")
    parser.add_argument("--surrogate-type",   default="gp", choices=["gp","rbf"])
    parser.add_argument("--doe-size",  type=int, default=None,
                        help="Override DoE size for surrogate / BO.")
    parser.add_argument("--bo-budget", type=int, default=None,
                        help="Override total BO budget.")
    parser.add_argument("--parallel",  action="store_true",
                        help="Enable parallel multi-start (ThreadPoolExecutor).")
    parser.add_argument("--workers",   type=int, default=4)
    parser.add_argument("--no-repair", action="store_true",
                        help="Disable feasibility repair post-processing.")
    parser.add_argument("--gradient-backend", default="jax", choices=["jax","fd"])
    # Pareto
    parser.add_argument("--pop-size",      type=int, default=100)
    parser.add_argument("--n-gen",         type=int, default=200)
    parser.add_argument("--pareto-polish", action="store_true")
    parser.add_argument("--pareto-out",    default=None, metavar="DIR")
    # CAD export
    parser.add_argument("--export-cad", default=None, choices=["openscad","freecad"])
    parser.add_argument("--cad-out",    default="./cad_output", metavar="DIR")
    # Misc
    parser.add_argument("--show-constraints", action="store_true")
    parser.add_argument("--dashboard", action="store_true")
    parser.add_argument("--test",      action="store_true")
    parser.add_argument("--verbose",   action="store_true")
    args = parser.parse_args(argv)

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    if args.test:
        _run_tests()
        return
    if args.dashboard:
        _launch_dashboard()
        return

    cfg = DomainConfig.from_file_or_empty(args.config)
    cfg.surrogate = args.surrogate_type
    if args.doe_size:  cfg.doe_size  = args.doe_size
    if args.bo_budget: cfg.bo_budget = args.bo_budget

    domain_obj = get_domain(args.domain, cfg)

    if args.show_constraints:
        from .runner import _sep
        _sep()
        print(f"  Constraint classification – {args.domain.upper()}")
        _sep()
        print(domain_obj.constraint_set().summary())
        _sep()
        return

    repair    = None if args.no_repair else get_feasibility_repair(domain_obj)
    workers   = args.workers if args.parallel else 1
    surrogate = None
    best      = None

    if args.mode in ("nsga2", "nsga3"):
        pareto_opt = get_pareto_optimizer(
            domain_obj, args.mode, args.pop_size, args.n_gen,
            args.seed, args.pareto_polish, workers,
        )
        front = run_pareto(domain_obj, args.domain, pareto_opt)
        if args.pareto_out:
            od = Path(args.pareto_out)
            od.mkdir(parents=True, exist_ok=True)
            front.to_csv(od / "pareto_front.csv")
            front.to_json(od / "pareto_front.json")
        bc = front.best_compromise()
        if bc is not None and args.export_cad:
            best_results = {**bc.all_kpis,
                            "geometry": domain_obj.geometry_generator.generate_geometry(bc.params)}
            from .interfaces import OptimResult
            best = OptimResult(
                optimized_params=bc.params, results=best_results,
                objective_value=sum(bc.objectives.values()),
                success=True, message="pareto_bc",
                n_iter=0, elapsed_s=front.elapsed_s, feasible=bc.feasible,
            )

    elif args.mode == "bayesopt":
        surrogate = get_surrogate(domain_obj, cfg)
        bo        = get_bo_optimizer(domain_obj, surrogate, cfg, seed=args.seed)
        best      = run_bayesopt(domain_obj, args.domain, bo)

    elif args.mode == "surrogate_single":
        surrogate = get_surrogate(domain_obj, cfg)
        best      = run_surrogate_single(domain_obj, args.domain, surrogate,
                                          cfg.doe_size, args.seed)
    elif args.mode == "single":
        optimizer = get_optimizer(domain_obj, args.mode)
        best      = run_single(domain_obj, args.domain, optimizer, repair=repair)

    elif args.mode == "differential_evo":
        optimizer = get_optimizer(domain_obj, args.mode, de_seed=args.seed)
        best      = run_differential_evo(domain_obj, args.domain, optimizer, repair=repair)

    else:  # monte_carlo / sobol
        optimizer = get_optimizer(domain_obj, args.mode)
        best      = run_sampling(domain_obj, args.domain, optimizer,
                                  mode=args.mode, n_runs=args.n_runs, seed=args.seed,
                                  repair=repair, max_workers=workers)

    if best is not None:
        if args.surrogate_stats:
            if surrogate is None:
                surrogate = get_surrogate(domain_obj, cfg)
                surrogate.fit(cfg.doe_size, domain_obj.effective_params(), seed=args.seed)
            stats = surrogate.stats_at(best.optimized_params)
            print("\n  Surrogate statistics at optimum:")
            print(stats.report())

        if args.tolerance_mc > 0:
            run_tolerance_study(best, domain_obj, args.domain,
                                args.tolerance_mc, args.seed, cfg.tols,
                                use_surrogate=False)

        if args.surrogate_tol_mc > 0:
            if surrogate is None:
                surrogate = get_surrogate(domain_obj, cfg)
                surrogate.fit(cfg.doe_size, domain_obj.effective_params(), seed=args.seed)
            run_tolerance_study(best, domain_obj, args.domain,
                                args.surrogate_tol_mc, args.seed, cfg.tols,
                                use_surrogate=True, surrogate=surrogate)

        if args.export_cad:
            _export_cad(best, domain_obj, args.export_cad, Path(args.cad_out))
