"""hardware_optimiser.sampling — LHS / Sobol sampling engine and multi-start runner."""

from __future__ import annotations

import logging
import math
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
from scipy.stats import qmc

from .interfaces import AbstractOptimizer, OptimResult

log = logging.getLogger("hardware_optimiser")

SamplingMode = str


# ── Low-discrepancy samplers ──────────────────────────────────────────────────

def _lhs(n: int, d: int, seed: int) -> np.ndarray:
    return qmc.LatinHypercube(d=d, seed=seed).random(n=n)


def _sobol(n: int, d: int, seed: int) -> np.ndarray:
    m = math.ceil(math.log2(max(n, 2)))
    return qmc.Sobol(d=d, scramble=True, seed=seed).random_base2(m=m)[:n]


def _scale(unit: np.ndarray, bounds: List[Tuple[float, float]]) -> np.ndarray:
    lo = np.array([b[0] for b in bounds])
    hi = np.array([b[1] for b in bounds])
    return lo + unit * (hi - lo)


# ── Results dataclass ─────────────────────────────────────────────────────────

@dataclass
class MultiStartResults:
    all_runs:        List[OptimResult]
    best:            OptimResult
    n_converged:     int
    mode:            SamplingMode
    n_runs:          int
    seed:            int
    total_elapsed_s: float

    def summary_table(self) -> str:
        hdr = (f"{'Run':>4}  {'Conv':>4}  {'Feas':>4}  "
               f"{'Iters':>5}  {'Objective':>14}  {'Time(s)':>9}")
        sep  = "-" * len(hdr)
        rows = [hdr, sep]
        for i, r in enumerate(self.all_runs):
            feas = getattr(r, "feasible", True)
            rows.append(
                f"{i+1:>4}  {'YES' if r.success else 'NO ':>4}  "
                f"{'YES' if feas else 'NO ':>4}  {r.n_iter:>5}  "
                f"{r.objective_value:>14.6g}  {r.elapsed_s:>9.3f}"
            )
        rows += [
            sep,
            f"Best obj={self.best.objective_value:.6g}  |  "
            f"Converged: {self.n_converged}/{self.n_runs}  |  "
            f"Total: {self.total_elapsed_s:.2f}s",
        ]
        return "\n".join(rows)


# ── Multi-start runner ────────────────────────────────────────────────────────

def run_multistart(
    optimizer:          AbstractOptimizer,
    base_params:        Dict[str, float],
    design_vars:        List[Tuple[str, Tuple[float, float]]],
    mode:               SamplingMode,
    n_runs:             int,
    seed:               int,
    feasibility_repair: Optional[object] = None,   # FeasibilityRepair | None
    max_workers:        int = 1,
) -> MultiStartResults:
    """
    Run *n_runs* SLSQP optimisations from LHS or Sobol start points.

    Parameters
    ----------
    optimizer:          Any AbstractOptimizer (usually GenericOptimizer).
    base_params:        Fixed / initial parameter dict.
    design_vars:        List of (name, (lo, hi)) design variable specs.
    mode:               "monte_carlo" (LHS) or "sobol".
    n_runs:             Number of start points.
    seed:               RNG seed.
    feasibility_repair: Optional FeasibilityRepair to apply after each run.
    max_workers:        Number of threads (1 = sequential).
    """
    d, bounds = len(design_vars), [b for _, b in design_vars]
    sampler   = _lhs if mode == "monte_carlo" else _sobol
    pts       = _scale(sampler(n_runs, d, seed), bounds)

    log.info("Multi-start [%s]: %d runs  seed=%d  workers=%d",
             mode, n_runs, seed, max_workers)

    all_runs: List[OptimResult] = []
    t0 = time.perf_counter()

    def _run_one(idx_x0: Tuple[int, np.ndarray]) -> Tuple[int, OptimResult]:
        i, x0 = idx_x0
        r = optimizer.optimize_design(base_params, x0_override=x0)
        if feasibility_repair is not None:
            r = feasibility_repair.repair(r)   # type: ignore[attr-defined]
        return i, r

    if max_workers > 1:
        results_map: Dict[int, OptimResult] = {}
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futs = {pool.submit(_run_one, (i, x0)): i
                    for i, x0 in enumerate(pts)}
            for fut in as_completed(futs):
                try:
                    i, r = fut.result()
                    results_map[i] = r
                except Exception as exc:
                    log.warning("Run %d failed: %s", futs[fut], exc)
        all_runs = [results_map[i] for i in range(n_runs) if i in results_map]
    else:
        for i, x0 in enumerate(pts):
            _, r = _run_one((i, x0))
            all_runs.append(r)

    total     = time.perf_counter() - t0
    converged = [r for r in all_runs if r.success]
    feasible  = [r for r in all_runs if getattr(r, "feasible", True)]
    best      = min((feasible or converged or all_runs), key=lambda r: r.objective_value)

    return MultiStartResults(
        all_runs=all_runs, best=best, n_converged=len(converged),
        mode=mode, n_runs=n_runs, seed=seed, total_elapsed_s=total,
    )
