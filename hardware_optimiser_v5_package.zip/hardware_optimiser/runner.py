"""hardware_optimiser.runner — run_* orchestration and display helpers (§15)."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, Optional

import numpy as np

from .autodiff   import GradientBackend
from .config     import DomainConfig
from .factory    import get_surrogate
from .interfaces import AbstractGeometryGenerator, AbstractOptimizer, HardwareDomain, OptimResult
from .optimizers import (
    DifferentialEvolutionOptimizer,
    FeasibilityRepair,
    NSGAParetoOptimizer,
    ParetoFront,
)
from .sampling   import run_multistart
from .surrogate  import BayesianOptimizer, SurrogateEvaluator
from .tolerance  import run_surrogate_tolerance_mc, run_tolerance_mc
from .optimizers import GenericOptimizer

log = logging.getLogger("hardware_optimiser")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _sep(c: str = "=", w: int = 68) -> None:
    print(c * w)


def _print_result(
    result:      OptimResult,
    gen:         AbstractGeometryGenerator,
    domain_name: str,
    label:       str = "",
) -> None:
    status = "SUCCEEDED" if result.success else "DID NOT CONVERGE"
    feas   = "FEASIBLE" if result.feasible else "⚠ INFEASIBLE"
    tag    = f"  [{label}]" if label else ""
    _sep()
    print(f"  {domain_name.upper()}{tag}  |  {status}  |  {feas}  "
          f"({result.n_iter} iters, {result.elapsed_s:.2f}s)")
    _sep()
    print(f"  Objective : {result.objective_value:.6g}")
    print("\nOptimised design variables:")
    for k, v in result.optimized_params.items():
        if isinstance(v, (int, float)):
            print(f"  {k:<36} = {v:.6g}")
    print("\nPerformance metrics:")
    for k, v in result.scalar_results().items():
        print(f"  {k:<36} = {v:.6g}")
    geo = result.results.get("geometry")
    if geo:
        print()
        print(gen.export_geometry(geo))


def _export_cad(
    result:     OptimResult,
    domain_obj: HardwareDomain,
    fmt:        str,
    out_dir:    Path,
) -> None:
    gen = domain_obj.geometry_generator
    if not hasattr(gen, "export_cad"):
        log.warning("Domain does not support CAD export.")
        return
    geo = result.results.get("geometry")
    if geo is None:
        try:
            geo = gen.generate_geometry(result.optimized_params)
        except Exception:
            log.warning("Cannot generate geometry for CAD export.")
            return
    out_dir.mkdir(parents=True, exist_ok=True)
    src = gen.export_cad(geo, result.optimized_params, fmt=fmt, out_dir=out_dir)
    print(f"\nCAD export ({fmt}) → {out_dir}")
    for ln in src.splitlines()[:6]:
        print("  " + ln)
    print("  ...")


# ── Optimisation runners ──────────────────────────────────────────────────────

def run_single(
    domain_obj:  HardwareDomain,
    domain_name: str,
    optimizer:   AbstractOptimizer,
    repair:      Optional[FeasibilityRepair] = None,
) -> OptimResult:
    params = domain_obj.effective_params()
    _sep()
    print(f"  Hardware Optimiser v5 – {domain_name.upper()}  [single]")
    _sep()
    result = optimizer.optimize_design(params)
    if repair:
        result = repair.repair(result)
    _print_result(result, domain_obj.geometry_generator, domain_name, label="single")
    _sep()
    return result


def run_sampling(
    domain_obj:  HardwareDomain,
    domain_name: str,
    optimizer:   AbstractOptimizer,
    mode:        str,
    n_runs:      int,
    seed:        int,
    repair:      Optional[FeasibilityRepair] = None,
    max_workers: int = 1,
) -> OptimResult:
    params = domain_obj.effective_params()
    dvars  = domain_obj.effective_design_vars()
    _sep()
    print(f"  Hardware Optimiser v5 – {domain_name.upper()}  "
          f"[{mode}  n={n_runs}  seed={seed}  workers={max_workers}]")
    _sep()
    ms = run_multistart(
        optimizer, params, dvars, mode=mode, n_runs=n_runs,
        seed=seed, feasibility_repair=repair, max_workers=max_workers,
    )
    print(f"\n{ms.summary_table()}\n")
    _print_result(ms.best, domain_obj.geometry_generator, domain_name, label="best")
    _sep()
    return ms.best


def run_differential_evo(
    domain_obj:  HardwareDomain,
    domain_name: str,
    optimizer:   DifferentialEvolutionOptimizer,
    repair:      Optional[FeasibilityRepair] = None,
) -> OptimResult:
    params = domain_obj.effective_params()
    _sep()
    print(f"  Hardware Optimiser v5 – {domain_name.upper()}  [differential_evo]")
    _sep()
    result = optimizer.optimize_design(params)
    if repair:
        result = repair.repair(result)
    _print_result(result, domain_obj.geometry_generator, domain_name, label="DE+polish")
    _sep()
    return result


def run_bayesopt(
    domain_obj:  HardwareDomain,
    domain_name: str,
    bo:          BayesianOptimizer,
) -> OptimResult:
    _sep()
    print(f"  Hardware Optimiser v5 – {domain_name.upper()}  [bayesopt]")
    _sep()
    bo_result = bo.run()
    print(bo_result.report())
    _sep()
    geo = domain_obj.geometry_generator.generate_geometry(bo_result.best_params)
    return OptimResult(
        optimized_params=bo_result.best_params,
        results={**bo_result.best_results, "geometry": geo},
        objective_value=bo_result.best_obj,
        success=True,
        message="bayesopt",
        n_iter=bo_result.n_total_evals,
        elapsed_s=bo_result.elapsed_s,
        feasible=bo_result.feasible,
    )


def run_surrogate_single(
    domain_obj:  HardwareDomain,
    domain_name: str,
    surrogate:   SurrogateEvaluator,
    doe_size:    int,
    seed:        int,
) -> OptimResult:
    """Fit surrogate on DoE, optimise on it, then re-evaluate best with physics."""
    _sep()
    print(f"  Hardware Optimiser v5 – {domain_name.upper()}  [surrogate_single]")
    _sep()
    params = domain_obj.effective_params()
    log.info("Fitting %s surrogate (DoE=%d)…", surrogate._model_type, doe_size)
    surrogate.fit(doe_size, params, seed=seed)

    wo   = domain_obj._build_objective()
    cset = domain_obj.constraint_set()
    opt  = GenericOptimizer(surrogate, wo, domain_obj.effective_design_vars(),
                            cset, backend=GradientBackend.FD)
    result_sur = opt.optimize_design(params)

    # Re-evaluate with true physics
    true_kpis = domain_obj.evaluator.evaluate(result_sur.optimized_params)
    true_obj  = float(wo(true_kpis))
    stats     = surrogate.stats_at(result_sur.optimized_params)
    print("\n  Surrogate statistics at predicted optimum:")
    print(stats.report())

    x_opt = np.array([result_sur.optimized_params.get(n, 0.0)
                      for n, _ in domain_obj.effective_design_vars()])
    result = OptimResult(
        optimized_params=result_sur.optimized_params,
        results=true_kpis,
        objective_value=true_obj,
        success=True,
        message="surrogate_single (physics re-evaluated)",
        n_iter=result_sur.n_iter,
        elapsed_s=result_sur.elapsed_s,
        feasible=cset.hard_feasible(x_opt, params),
    )
    _print_result(result, domain_obj.geometry_generator, domain_name, label="surrogate")
    _sep()
    return result


def run_pareto(
    domain_obj:  HardwareDomain,
    domain_name: str,
    pareto_opt:  NSGAParetoOptimizer,
) -> ParetoFront:
    _sep()
    print(f"  Hardware Optimiser v5 – {domain_name.upper()}  "
          f"[{pareto_opt._mode.upper()} Pareto]")
    print(f"  Objectives: {pareto_opt._obj_keys}")
    _sep()
    front = pareto_opt.run()
    print(front.summary())
    bc = front.best_compromise()
    if bc is not None:
        print("\n  Best-compromise solution:")
        for k, v in bc.objectives.items():
            print(f"    {k:<40} = {v:.5g}")
        try:
            geo = domain_obj.geometry_generator.generate_geometry(bc.params)
            print("\n  " + domain_obj.geometry_generator.export_geometry(geo))
        except Exception:
            pass
    _sep()
    return front


def run_tolerance_study(
    best:        OptimResult,
    domain_obj:  HardwareDomain,
    domain_name: str,
    n_samples:   int,
    seed:        int,
    config_tols: Dict[str, float],
    use_surrogate: bool = False,
    surrogate:   Optional[SurrogateEvaluator] = None,
) -> None:
    _sep("-")
    print(f"  Tolerance MC – {domain_name.upper()}  "
          f"(n={n_samples}, seed={seed}, surrogate={use_surrogate})")
    _sep("-")
    tols_all   = {**domain_obj.default_tols(), **config_tols}
    tol_params = {k: tols_all[k]
                  for k in domain_obj.evaluator.tolerance_params
                  if k in tols_all}
    if not tol_params:
        log.warning("No tolerance params resolved for '%s'. Skipping.", domain_name)
        return

    cfuncs = domain_obj.constraint_funcs()
    if use_surrogate and surrogate is not None and surrogate._fitted:
        stol = run_surrogate_tolerance_mc(
            best.optimized_params, surrogate, cfuncs,
            domain_obj.effective_design_vars(), tol_params, n_samples, seed,
        )
        print(stol.report())
    else:
        mc = run_tolerance_mc(
            best.optimized_params, domain_obj.evaluator, cfuncs,
            domain_obj.effective_design_vars(), tol_params, n_samples, seed,
        )
        print(mc.report())
    _sep("-")
