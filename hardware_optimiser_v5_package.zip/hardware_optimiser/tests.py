"""hardware_optimiser.tests — 17 unit tests, no pytest required (§16)."""

from __future__ import annotations

import math
import traceback as _tb
from typing import Callable, List

import numpy as np

from ._compat import JAX_AVAILABLE
from .config   import DomainConfig
from .constraints import ClassifiedConstraint, ConstraintKind, ConstraintSet
from .domains.centrifugal_pump import (
    CentrifugalPumpDomain, _pump_tip_speed,
)
from .domains.electric_motor import _pmsm_torque
from .domains.nozzle import (
    NozzleDomain, _nozzle_exit_mach, _nozzle_exit_velocity,
)
from .dataclasses_ import NozzleParams
from .objective import ObjectiveTerm, WeightedObjective
from .optimizers import ParetoFront, ParetoSolution
from .surrogate  import SurrogateEvaluator, SurrogateStats
from .tolerance  import MassModelRegistry

# JAX nozzle helpers (conditional)
if JAX_AVAILABLE:
    from .domains.nozzle import _jnozzle_isp


def _run_tests() -> None:
    """Run all 17 unit tests.  Raises SystemExit(1) on any failure."""
    passed: List[str] = []
    failed: List[str] = []

    def _test(name: str, fn: Callable[[], None]) -> None:
        try:
            fn()
            passed.append(name)
            print(f"  PASS  {name}")
        except Exception as exc:
            failed.append(name)
            print(f"  FAIL  {name}: {exc}")
            _tb.print_exc()

    print("\n" + "="*60 + "\n  Unit Tests  (v5)\n" + "="*60)

    # T1 – Nozzle exit velocity: isentropic formula
    def _t1() -> None:
        subs = {"gamma": 1.4, "R": 287.0, "T0": 300.0, "Me": 2.0}
        expected = 2.0 * math.sqrt(1.4 * 287.0 * 300.0 / (1.0 + 0.2 * 4.0))
        assert abs(_nozzle_exit_velocity(subs) - expected) < 0.05

    # T2 – Nozzle area-ratio Brent round-trip
    def _t2() -> None:
        gamma, Me_in = 1.4, 2.5
        gp1, gm1 = gamma + 1.0, gamma - 1.0
        ar = (1.0/Me_in) * ((2.0/gp1)*(1.0+0.5*gm1*Me_in**2))**(0.5*gp1/gm1)
        Me_out = _nozzle_exit_mach({"gamma": gamma, "area_ratio": ar})
        assert abs(Me_out - Me_in) < 1e-6

    # T3 – PMSM torque formula
    def _t3() -> None:
        subs = {"pole_pairs": 4.0, "flux_linkage_pm": 0.05,
                "current_q": 100.0, "rotor_radius": 0.07}
        assert abs(_pmsm_torque(subs) - 30.0) < 1e-9

    # T4 – Pump tip speed
    def _t4() -> None:
        subs = {"rotational_speed_rpm": 1450.0, "impeller_diameter_m": 0.25}
        assert abs(_pump_tip_speed(subs) - math.pi*1450.0*0.25/60.0) < 1e-9

    # T5 – WeightedObjective: at nominal → zero; higher is better
    def _t5() -> None:
        terms = [ObjectiveTerm("eff", -1.0, 0.8)]
        wo = WeightedObjective(terms, {})
        assert wo({"eff": 0.8}) == 0.0
        assert wo({"eff": 1.0}) < wo({"eff": 0.5})

    # T6 – DomainConfig bound override flows through effective_design_vars
    def _t6() -> None:
        cfg   = DomainConfig(bounds={"impeller_diameter_m": (0.10, 0.60)})
        dvars = dict(CentrifugalPumpDomain(cfg).effective_design_vars())
        lo, hi = dvars["impeller_diameter_m"]
        assert abs(lo-0.10) < 1e-9 and abs(hi-0.60) < 1e-9

    # T7 – JAX gradient of Isp wrt Me (vs finite differences)
    def _t7() -> None:
        if not JAX_AVAILABLE:
            return
        from jax import grad as _g
        p = NozzleParams()
        isp_fn = lambda Me: _jnozzle_isp(Me, p.gamma, p.R, p.T0)
        g_jax = float(_g(isp_fn)(3.0))
        eps   = 1e-6
        g_fd  = (float(isp_fn(3.0+eps)) - float(isp_fn(3.0-eps))) / (2*eps)
        assert abs(g_jax - g_fd) / (abs(g_fd)+1e-30) < 1e-4, \
            f"JAX grad err: jax={g_jax:.6g} fd={g_fd:.6g}"

    # T8 – ConstraintSet hard feasibility
    def _t8() -> None:
        def _f(x, b): return float(x[0]) - 1.0
        cs = ConstraintSet([ClassifiedConstraint("c1", ConstraintKind.HARD_INEQ, _f)])
        assert cs.hard_feasible(np.array([1.5]), {})
        assert not cs.hard_feasible(np.array([0.5]), {})

    # T9 – ConstraintSet soft penalty only when violated
    def _t9() -> None:
        def _f(x, b): return float(x[0]) - 0.8
        cs = ConstraintSet([ClassifiedConstraint("s1", ConstraintKind.SOFT, _f, penalty_k=100.0)])
        assert cs.hard_feasible(np.array([0.5]), {})   # SOFT ignored by hard check
        assert cs.penalty(np.array([0.5]), {}) > 0.0
        assert cs.penalty(np.array([0.9]), {}) == 0.0

    # T10 – ConstraintSpec → build_constraint_set round-trip
    def _t10() -> None:
        domain = NozzleDomain(DomainConfig.empty())
        cset   = domain.constraint_set()
        assert cset.n_constraints >= 1, "Nozzle must have ≥1 constraint"

    # T11 – Config kind override changes classification
    def _t11() -> None:
        cfg    = DomainConfig(constraint_kinds={"isp_ge_min": "soft"})
        domain = NozzleDomain(cfg)
        cset   = domain.constraint_set()
        kinds  = {c.name: c.kind for c in cset._all}
        assert kinds["isp_ge_min"] == ConstraintKind.SOFT, \
            f"Expected SOFT, got {kinds['isp_ge_min']}"

    # T12 – SurrogateEvaluator fit + predict
    def _t12() -> None:
        domain = NozzleDomain(DomainConfig.empty())
        sur    = SurrogateEvaluator(domain.evaluator, domain.effective_design_vars(),
                                    model_type="rbf")
        sur.fit(12, domain.effective_params(), seed=0)
        p      = domain.effective_params()
        x_raw  = np.array([p.get(n, 0.0) for n, _ in domain.effective_design_vars()])
        mu, std = sur.predict_with_uncertainty(x_raw)
        assert len(mu) > 0
        assert all(s >= 0 for s in std)

    # T13 – SurrogateStats structure
    def _t13() -> None:
        domain = NozzleDomain(DomainConfig.empty())
        sur    = SurrogateEvaluator(domain.evaluator, domain.effective_design_vars(),
                                    model_type="rbf")
        sur.fit(10, domain.effective_params(), seed=1)
        stats = sur.stats_at(domain.effective_params())
        assert isinstance(stats, SurrogateStats)
        assert set(stats.mean.keys()) == set(stats.std.keys())

    # T14 – SurrogateEvaluator.update appends and refits
    def _t14() -> None:
        domain = NozzleDomain(DomainConfig.empty())
        sur    = SurrogateEvaluator(domain.evaluator, domain.effective_design_vars(),
                                    model_type="rbf")
        sur.fit(8, domain.effective_params(), seed=2)
        n_before = sur.n_training_points
        kpis = {k: 1.0 for k in sur._kpi_keys}
        sur.update(domain.effective_params(), kpis)
        assert sur.n_training_points == n_before + 1

    # T15 – ParetoFront best_compromise
    def _t15() -> None:
        sols = [
            ParetoSolution({}, {"a": 0.0, "b": 1.0}, {}, feasible=True),
            ParetoSolution({}, {"a": 1.0, "b": 0.0}, {}, feasible=True),
            ParetoSolution({}, {"a": 0.5, "b": 0.5}, {}, feasible=True),
        ]
        front = ParetoFront(sols, ["a","b"], "nsga2", 0, 0, 0.0)
        bc    = front.best_compromise()
        assert bc is not None
        assert abs(bc.objectives["a"] - 0.5) < 0.01

    # T16 – OpenSCAD nozzle export contains required keywords
    def _t16() -> None:
        domain = NozzleDomain(DomainConfig.empty())
        geo    = domain.geometry_generator.generate_geometry(domain.effective_params())
        src    = domain.geometry_generator.export_cad(geo, domain.effective_params())
        assert "rotate_extrude" in src
        assert "r_throat" in src

    # T17 – MassModelRegistry table interpolation
    def _t17() -> None:
        cfg_dict = {"nozzle": {"model_type": "table", "x_key": "throat_radius",
                               "x": [0.02, 0.05, 0.10], "mass_kg": [1.0, 3.0, 8.0]}}
        reg = MassModelRegistry("nozzle", cfg_dict)
        assert abs(reg.calculate({"throat_radius": 0.05},  lambda p: 999.0) - 3.0) < 1e-9
        assert abs(reg.calculate({"throat_radius": 0.075}, lambda p: 999.0) - 5.5) < 1e-9

    for name, fn in [
        ("T1   Nozzle exit velocity",           _t1),
        ("T2   Nozzle area-ratio round-trip",    _t2),
        ("T3   PMSM torque formula",             _t3),
        ("T4   Pump tip speed formula",          _t4),
        ("T5   WeightedObjective normalise",     _t5),
        ("T6   DomainConfig bound override",     _t6),
        ("T7   JAX grad of Isp wrt Me",          _t7),
        ("T8   ConstraintSet hard feasibility",  _t8),
        ("T9   ConstraintSet soft penalty",      _t9),
        ("T10  ConstraintSpec build round-trip", _t10),
        ("T11  Config constraint kind override", _t11),
        ("T12  Surrogate fit + predict",         _t12),
        ("T13  SurrogateStats structure",        _t13),
        ("T14  Surrogate update (active learn)", _t14),
        ("T15  ParetoFront best_compromise",     _t15),
        ("T16  OpenSCAD nozzle export",          _t16),
        ("T17  MassModelRegistry table interp",  _t17),
    ]:
        _test(name, fn)

    print("=" * 60)
    print(f"  {len(passed)} passed  |  {len(failed)} failed")
    print("=" * 60 + "\n")
    if failed:
        raise SystemExit(1)
