"""hardware_optimiser.registry — per-domain physics function registry."""

from __future__ import annotations

import logging
from typing import Callable, Dict

log = logging.getLogger("hardware_optimiser")

PhysicsFunc = Callable[[Dict[str, float]], float]


class PhysicsRegistry:
    """
    Named registry of scalar physics functions subs → float.

    Used by each domain's Axioms class to organise and dispatch
    physics computations without global state.
    """

    def __init__(self, domain_name: str) -> None:
        self._name = domain_name
        self._reg: Dict[str, PhysicsFunc] = {}

    def register(self, quantities: Dict[str, PhysicsFunc]) -> None:
        dup = set(quantities) & set(self._reg)
        if dup:
            log.warning("PhysicsRegistry[%s]: overwriting %s.", self._name, dup)
        self._reg.update(quantities)

    def evaluate(self, quantity: str, subs: Dict[str, float]) -> float:
        if quantity not in self._reg:
            raise KeyError(
                f"PhysicsRegistry[{self._name}]: '{quantity}' not found. "
                f"Available: {sorted(self._reg)}"
            )
        return self._reg[quantity](subs)

    def __repr__(self) -> str:
        return f"PhysicsRegistry({self._name!r}, {sorted(self._reg)})"
