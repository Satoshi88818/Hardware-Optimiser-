"""hardware_optimiser.interfaces — abstract base classes and core result types."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np

log = logging.getLogger("hardware_optimiser")


# ── Physics / Simulation ABCs ─────────────────────────────────────────────────

class AbstractAxioms(ABC):
    @abstractmethod
    def evaluate(self, quantity: str, subs: Dict[str, float]) -> float: ...


class AbstractConstraints(ABC):
    @abstractmethod
    def get_funcs(self) -> List[Callable[[np.ndarray, Dict[str, float]], float]]: ...


class AbstractGeometryGenerator(ABC):
    @abstractmethod
    def generate_geometry(self, params: Dict[str, float]) -> Dict[str, float]: ...

    @abstractmethod
    def calculate_mass(self, geo: Dict[str, float], params: Dict[str, float]) -> float: ...

    @abstractmethod
    def export_geometry(self, geo: Dict[str, float]) -> str: ...


class AbstractGeometryExporter(ABC):
    """Pluggable CAD export target (OpenSCAD, FreeCAD, …)."""

    format_name: str = "text"

    @abstractmethod
    def export(self, geo: Dict[str, float], params: Dict[str, float]) -> str: ...

    def write(self, geo: Dict[str, float], params: Dict[str, float], path: Path) -> None:
        path.write_text(self.export(geo, params), encoding="utf-8")
        log.info("CAD export written to %s", path)


class AbstractSimulator(ABC):
    @abstractmethod
    def simulate(self, params: Dict[str, float]) -> Dict[str, float]: ...


class AbstractEvaluator(ABC):
    @abstractmethod
    def evaluate(self, params: Dict[str, float]) -> Dict[str, Any]: ...

    @property
    @abstractmethod
    def tolerance_params(self) -> List[str]: ...


class AbstractOptimizer(ABC):
    @abstractmethod
    def optimize_design(
        self,
        initial_params: Dict[str, float],
        x0_override: Optional[np.ndarray] = None,
    ) -> "OptimResult": ...


# ── Optimisation result ───────────────────────────────────────────────────────

@dataclass
class OptimResult:
    optimized_params: Dict[str, float]
    results:          Dict[str, Any]
    objective_value:  float
    success:          bool
    message:          str
    n_iter:           int
    elapsed_s:        float
    feasible:         bool = True

    def scalar_results(self) -> Dict[str, float]:
        return {k: float(v) for k, v in self.results.items()
                if isinstance(v, (int, float)) and k != "geometry"}


# ── Hardware domain base class ────────────────────────────────────────────────

class HardwareDomain(ABC):
    """
    Abstract base for all engineering domains.

    Concrete domains implement the abstract properties and methods.
    The concrete ``constraint_set()`` / ``constraint_funcs()`` methods
    delegate to ``build_constraint_set`` (imported lazily to avoid circularity).
    """

    def __init__(self, config: "DomainConfig") -> None:  # type: ignore[name-defined]
        self._config = config

    # ── abstract properties ────────────────────────────────────────────────────
    @property
    @abstractmethod
    def axioms(self) -> AbstractAxioms: ...

    @property
    @abstractmethod
    def constraints(self) -> AbstractConstraints: ...

    @property
    @abstractmethod
    def geometry_generator(self) -> AbstractGeometryGenerator: ...

    @property
    @abstractmethod
    def evaluator(self) -> AbstractEvaluator: ...

    @property
    @abstractmethod
    def optimizer(self) -> AbstractOptimizer: ...

    @property
    @abstractmethod
    def design_vars(self) -> List[Tuple[str, Tuple[float, float]]]: ...

    @property
    @abstractmethod
    def default_weights(self) -> Dict[str, float]: ...

    @property
    @abstractmethod
    def default_params(self) -> Dict[str, float]: ...

    @property
    @abstractmethod
    def default_pareto_objectives(self) -> List[str]: ...

    @property
    @abstractmethod
    def constraint_specs(self) -> List[Any]:  # List[ConstraintSpec]
        """Return declarative ConstraintSpec list (imported from constraints module)."""
        ...

    # ── concrete helpers ───────────────────────────────────────────────────────
    def effective_params(self) -> Dict[str, float]:
        known = set(self.default_params.keys())
        unknown = set(self._config.params.keys()) - known
        if unknown:
            log.warning("Config params contain unknown keys: %s", unknown)
        return {**self.default_params, **self._config.params}

    def effective_design_vars(self) -> List[Tuple[str, Tuple[float, float]]]:
        return [(n, self._config.bounds.get(n, b)) for n, b in self.design_vars]

    def effective_weights(self) -> Dict[str, float]:
        return {**self.default_weights, **self._config.weights}

    def effective_pareto_objectives(self) -> List[str]:
        return self._config.objectives or self.default_pareto_objectives

    def default_tols(self) -> Dict[str, float]:
        return {}

    def constraint_set(self) -> Any:  # -> ConstraintSet
        from .constraints import build_constraint_set
        return build_constraint_set(
            self.constraint_specs,
            self.evaluator,
            self.effective_design_vars(),
            self._config.constraint_kinds,
        )

    def constraint_funcs(self) -> List[Callable[[np.ndarray, Dict[str, float]], float]]:
        return [c.fun for c in self.constraint_set()._all]

    @abstractmethod
    def _build_objective(self) -> Any:  # -> WeightedObjective
        ...
