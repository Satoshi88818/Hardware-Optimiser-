"""hardware_optimiser.dataclasses_ — per-domain frozen I/O dataclasses."""

from __future__ import annotations

from dataclasses import asdict, dataclass, fields
from typing import Any, Dict, Type


# ── helpers ───────────────────────────────────────────────────────────────────

def _to_dict(obj: Any) -> Dict[str, float]:
    return {f.name: getattr(obj, f.name) for f in fields(obj)}


def _from_dict(cls: Type, d: Dict[str, float]) -> Any:
    known = {f.name for f in fields(cls)}
    return cls(**{k: v for k, v in d.items() if k in known})


# ── Nozzle ────────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class NozzleParams:
    gamma: float = 1.24;    R: float = 400.0;      T0: float = 3500.0
    P0: float = 10.0e6;     Pa: float = 101325.0;  m_dot: float = 5.0
    throat_radius: float = 0.05;  Me: float = 3.0

    def to_dict(self) -> Dict[str, float]: return _to_dict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, float]) -> "NozzleParams":
        return _from_dict(cls, d)


@dataclass(frozen=True)
class NozzleResults:
    exit_mach: float; exit_velocity: float; thrust: float
    specific_impulse: float; area_ratio: float; mass: float
    throat_radius: float; exit_radius: float; nozzle_length: float

    def scalar_metrics(self) -> Dict[str, float]: return asdict(self)


# ── Electric Motor ────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class MotorParams:
    pole_pairs: float = 4.0;       turns_per_phase: float = 12.0
    winding_factor: float = 0.933; omega_mech: float = 300.0
    rotor_radius: float = 0.07;    stack_length: float = 0.12
    B_gap: float = 0.85;           current_q: float = 200.0

    def to_dict(self) -> Dict[str, float]: return _to_dict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, float]) -> "MotorParams":
        return _from_dict(cls, d)


@dataclass(frozen=True)
class MotorResults:
    flux_linkage_pm: float; torque: float; power: float
    power_density: float; current_density: float; mass: float
    r_rotor: float; r_stator_inner: float; r_stator_outer: float
    stack_length: float; slot_area: float

    def scalar_metrics(self) -> Dict[str, float]: return asdict(self)


# ── Centrifugal Pump ──────────────────────────────────────────────────────────

@dataclass(frozen=True)
class PumpParams:
    flow_rate_m3s: float = 0.05;         fluid_density_kgm3: float = 998.0
    target_head_m: float = 50.0;         impeller_diameter_m: float = 0.25
    blade_angle_deg: float = 30.0;       rotational_speed_rpm: float = 1450.0
    inlet_diameter_ratio: float = 0.45;  blade_width_ratio: float = 0.10
    n_blades: float = 6.0;               slip_factor_model: float = 0.9

    def to_dict(self) -> Dict[str, float]: return _to_dict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, float]) -> "PumpParams":
        return _from_dict(cls, d)


@dataclass(frozen=True)
class PumpResults:
    head_m: float; shaft_power_W: float; hydraulic_efficiency: float
    specific_speed: float; tip_speed_m_s: float; mass_impeller_kg: float
    power_per_kg_W_kg: float; npsh_r_m: float

    def scalar_metrics(self) -> Dict[str, float]: return asdict(self)
