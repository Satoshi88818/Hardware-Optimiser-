"""hardware_optimiser.constraints — constraint classification and ConstraintSet."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np

from .interfaces import AbstractEvaluator

log = logging.getLogger("hardware_optimiser")


# ── Kind enum ─────────────────────────────────────────────────────────────────

class ConstraintKind(str, Enum):
    HARD_EQ   = "hard_eq"    # g(x) == 0   — projected by FeasibilityRepair
    HARD_INEQ = "hard_ineq"  # g(x) >= 0   — projected by FeasibilityRepair
    SOFT      = "soft"       # g(x) >= 0   — penalised, never projected


# ── Declarative specification (domain-owned) ──────────────────────────────────

@dataclass
class ConstraintSpec:
    """
    Declarative description of one constraint, owned by the domain.

    Fields
    ------
    name:      Unique string key; used by DomainConfig.constraint_kinds to override.
    kpi:       KPI key in the evaluator result dict.
    sense:     "ge"  →  kpi ≥ bound  (g = kpi − bound)
               "le"  →  kpi ≤ bound  (g = bound − kpi)
    bound:     Constraint right-hand side.
    kind:      Default classification (can be overridden via config).
    penalty_k: Coefficient for soft-constraint quadratic penalty.
    """
    name:      str
    kpi:       str
    sense:     str
    bound:     float
    kind:      ConstraintKind = ConstraintKind.HARD_INEQ
    penalty_k: float          = 500.0


# ── Live constraint (spec + evaluable callable) ───────────────────────────────

@dataclass
class ClassifiedConstraint:
    name:      str
    kind:      ConstraintKind
    fun:       Callable[[np.ndarray, Dict[str, float]], float]
    penalty_k: float = 500.0
    tol:       float = 1e-6


# ── Factory ───────────────────────────────────────────────────────────────────

def build_constraint_set(
    specs:          List[ConstraintSpec],
    evaluator:      AbstractEvaluator,
    design_vars:    List[Tuple[str, Tuple[float, float]]],
    kind_overrides: Dict[str, str],
) -> "ConstraintSet":
    """
    Construct a ConstraintSet from domain-declared ConstraintSpecs.

    ``kind_overrides`` (from DomainConfig.constraint_kinds) can reclassify
    any constraint by name, e.g. ``{"head_ge_min": "soft"}``.
    """
    cc_list: List[ClassifiedConstraint] = []

    for spec in specs:
        raw_kind = kind_overrides.get(spec.name, spec.kind.value)
        try:
            kind = ConstraintKind(raw_kind)
        except ValueError:
            log.warning(
                "Unknown constraint kind '%s' for '%s'; defaulting to hard_ineq.",
                raw_kind, spec.name,
            )
            kind = ConstraintKind.HARD_INEQ

        kpi, sense, bound = spec.kpi, spec.sense, spec.bound

        def _make_fun(
            k: str, s: str, b: float,
            dv: List[Tuple[str, Tuple[float, float]]],
        ) -> Callable[[np.ndarray, Dict[str, float]], float]:
            def _con(x: np.ndarray, base: Dict[str, float]) -> float:
                p = dict(base)
                for i, (n, _) in enumerate(dv):
                    p[n] = float(x[i])
                v = evaluator.evaluate(p).get(k, 0.0)
                return float((v - b) if s == "ge" else (b - v))
            return _con

        cc_list.append(ClassifiedConstraint(
            name=spec.name,
            kind=kind,
            fun=_make_fun(kpi, sense, bound, design_vars),
            penalty_k=spec.penalty_k,
        ))

    return ConstraintSet(cc_list)


# ── ConstraintSet ─────────────────────────────────────────────────────────────

class ConstraintSet:
    """
    Unified constraint container.

    Serves SLSQP (``slsqp_constraints``), DE (``penalty``),
    NSGA (``as_pymoo_G``), FeasibilityRepair (``hard_feasible``),
    and the BO loop (``hard_feasible``).
    """

    def __init__(self, constraints: List[ClassifiedConstraint]) -> None:
        self._all = constraints

    def add(self, c: ClassifiedConstraint) -> None:
        self._all.append(c)

    # ── internal helpers ──────────────────────────────────────────────────────

    def _eval(self, c: ClassifiedConstraint, x: np.ndarray,
              base: Dict[str, float]) -> float:
        try:
            return float(c.fun(x, base))
        except Exception:
            return -1e9

    # ── public API ────────────────────────────────────────────────────────────

    def violations(self, x: np.ndarray, base: Dict[str, float]) -> Dict[str, float]:
        """Return per-constraint violation amounts (0 when satisfied)."""
        out: Dict[str, float] = {}
        for c in self._all:
            v = self._eval(c, x, base)
            out[c.name] = abs(v) if c.kind == ConstraintKind.HARD_EQ else max(0.0, -v)
        return out

    def hard_feasible(self, x: np.ndarray, base: Dict[str, float]) -> bool:
        """True when all HARD_EQ and HARD_INEQ constraints are satisfied."""
        for c in self._all:
            if c.kind == ConstraintKind.SOFT:
                continue
            v = self._eval(c, x, base)
            if c.kind == ConstraintKind.HARD_EQ and abs(v) > c.tol:
                return False
            if c.kind == ConstraintKind.HARD_INEQ and v < -c.tol:
                return False
        return True

    def all_feasible(self, x: np.ndarray, base: Dict[str, float]) -> bool:
        """True when all constraints (including SOFT) are satisfied."""
        for c in self._all:
            v = self._eval(c, x, base)
            if c.kind == ConstraintKind.HARD_EQ and abs(v) > c.tol:
                return False
            if c.kind in (ConstraintKind.HARD_INEQ, ConstraintKind.SOFT) and v < -c.tol:
                return False
        return True

    def penalty(self, x: np.ndarray, base: Dict[str, float]) -> float:
        """Quadratic penalty for SOFT constraint violations."""
        p = 0.0
        for c in self._all:
            if c.kind != ConstraintKind.SOFT:
                continue
            v = self._eval(c, x, base)
            if v < 0.0:
                p += c.penalty_k * v**2
        return p

    def slsqp_constraints(self, base: Dict[str, float]) -> List[Dict[str, Any]]:
        """Convert HARD constraints to scipy.optimize.minimize-compatible dicts."""
        out = []
        for c in self._all:
            if c.kind == ConstraintKind.SOFT:
                continue
            ctype = "eq" if c.kind == ConstraintKind.HARD_EQ else "ineq"
            out.append({"type": ctype, "fun": c.fun, "args": (base,)})
        return out

    def as_pymoo_G(self, x: np.ndarray, base: Dict[str, float]) -> np.ndarray:
        """pymoo convention: G ≤ 0 is feasible → negate our g ≥ 0 convention."""
        return np.array([-self._eval(c, x, base) for c in self._all])

    @property
    def n_constraints(self) -> int:
        return len(self._all)

    @property
    def hard_only(self) -> "ConstraintSet":
        return ConstraintSet([c for c in self._all if c.kind != ConstraintKind.SOFT])

    def summary(self) -> str:
        lines = [f"  {'Name':<48} {'Kind':<14} {'Penalty_k':>9}"]
        lines.append("  " + "-" * 74)
        for c in self._all:
            lines.append(
                f"  {c.name:<48} {c.kind.value:<14} {c.penalty_k:>9.0f}"
            )
        return "\n".join(lines)
