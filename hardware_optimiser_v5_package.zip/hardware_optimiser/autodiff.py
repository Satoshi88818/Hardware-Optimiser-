"""hardware_optimiser.autodiff — JAX automatic differentiation gradient provider."""

from __future__ import annotations

import logging
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np

from ._compat import JAX_AVAILABLE, _jax_grad, _jax_jit, jnp
from .interfaces import AbstractEvaluator
from .objective import WeightedObjective

log = logging.getLogger("hardware_optimiser")


class GradientBackend(str, Enum):
    JAX = "jax"
    FD  = "fd"    # central finite-difference fallback


class JaxGradientProvider:
    """
    Computes ∂f/∂x for a scalar objective f(x: array) → scalar via JAX.

    Falls back transparently to central finite differences when JAX is
    unavailable or when the traced graph contains non-differentiable ops
    (e.g. scipy brentq).

    Parameters
    ----------
    obj_fn:      Scalar objective  f(x: np.ndarray | jnp.ndarray) → scalar.
    design_vars: List of (name, (lo, hi)) tuples (used only for n_dvars).
    backend:     GradientBackend.JAX (default) or GradientBackend.FD.
    eps_fd:      Step size for central finite differences.
    """

    def __init__(
        self,
        obj_fn:      Callable,
        design_vars: List[Tuple[str, Tuple[float, float]]],
        backend:     GradientBackend = GradientBackend.JAX,
        eps_fd:      float = 1e-6,
    ) -> None:
        self._fn      = obj_fn
        self._n       = len(design_vars)
        self._backend = backend
        self._eps     = eps_fd
        self._jax_grad_fn: Optional[Callable] = None

        if backend == GradientBackend.JAX and JAX_AVAILABLE:
            try:
                self._jax_grad_fn = _jax_jit(_jax_grad(obj_fn))
            except Exception as exc:
                log.debug("JAX trace failed at construction: %s", exc)
                self._backend = GradientBackend.FD
        elif backend == GradientBackend.JAX:
            log.warning("JAX not available — falling back to finite differences.")
            self._backend = GradientBackend.FD

    def grad(self, x: np.ndarray) -> np.ndarray:
        if self._backend == GradientBackend.JAX and self._jax_grad_fn is not None:
            try:
                return np.asarray(
                    self._jax_grad_fn(jnp.array(x, dtype=jnp.float64))
                )
            except Exception as exc:
                log.debug("JAX grad failed (%s); falling back to FD.", exc)

        # Central finite differences
        g = np.zeros(self._n)
        for i in range(self._n):
            xp, xm = x.copy(), x.copy()
            xp[i] += self._eps
            xm[i] -= self._eps
            g[i] = (self._fn(xp) - self._fn(xm)) / (2.0 * self._eps)
        return g

    def jac_callable(self) -> Callable[[np.ndarray], np.ndarray]:
        """Return a Jacobian callable compatible with ``scipy.optimize.minimize``."""
        return lambda x: self.grad(np.asarray(x, dtype=float))


def make_jax_objective(
    evaluator:   AbstractEvaluator,
    wo:          WeightedObjective,
    design_vars: List[Tuple[str, Tuple[float, float]]],
    base_params: Dict[str, float],
) -> Callable:
    """
    Build a flat-vector objective  f(x) → scalar  suitable for JAX tracing.

    The evaluator is called with plain-float dicts.  JAX traces through
    numpy-compatible operations; non-differentiable ops (brentq, etc.) produce
    opaque boxes whose gradients silently fall back to FD in JaxGradientProvider.
    """
    dvar_names = [n for n, _ in design_vars]

    def _obj(x: Any) -> Any:
        p = dict(base_params)
        for i, n in enumerate(dvar_names):
            p[n] = float(x[i]) if not JAX_AVAILABLE else x[i]
        results = evaluator.evaluate(p)
        total   = 0.0
        for t in wo.terms:
            val   = results.get(t.kpi_key, 0.0)
            denom = abs(t.nominal) if t.nominal != 0.0 else 1.0
            total = total + t.weight * (val - t.nominal) / denom
            if t.constraint is not None:
                sense, bound = t.constraint
                denom_c = abs(bound) if bound != 0.0 else 1.0
                if sense == "ge":
                    viol = bound - val
                    total = total + t.penalty_k * (viol if viol > 0 else 0.0) / denom_c
                else:
                    viol = val - bound
                    total = total + t.penalty_k * (viol if viol > 0 else 0.0) / denom_c
        return total

    return _obj
