"""hardware_optimiser.factory — domain factory and convenience constructors (§14)."""

from __future__ import annotations

from typing import Dict, Type

from .config    import DomainConfig
from .interfaces import AbstractOptimizer, HardwareDomain
from .optimizers import (
    DifferentialEvolutionOptimizer,
    FeasibilityRepair,
    NSGAParetoOptimizer,
)
from .surrogate import BayesianOptimizer, SurrogateEvaluator

# Domain registry — populated after importing concrete implementations.
from .domains.nozzle           import NozzleDomain
from .domains.electric_motor   import ElectricMotorDomain
from .domains.centrifugal_pump import CentrifugalPumpDomain

_DOMAIN_MAP: Dict[str, Type[HardwareDomain]] = {
    "nozzle":           NozzleDomain,
    "electric_motor":   ElectricMotorDomain,
    "centrifugal_pump": CentrifugalPumpDomain,
}


def get_domain(name: str, config: DomainConfig) -> HardwareDomain:
    """Instantiate a domain by name with the given config."""
    if name not in _DOMAIN_MAP:
        raise ValueError(
            f"Domain '{name}' not supported. Available: {sorted(_DOMAIN_MAP)}"
        )
    return _DOMAIN_MAP[name](config)


def get_optimizer(
    domain_obj: HardwareDomain,
    mode: str,
    de_seed: int = 0,
) -> AbstractOptimizer:
    """Return the appropriate optimizer for *mode*."""
    if mode == "differential_evo":
        wo   = domain_obj._build_objective()
        cset = domain_obj.constraint_set()
        return DifferentialEvolutionOptimizer(
            domain_obj.evaluator, wo,
            domain_obj.effective_design_vars(),
            cset, de_seed=de_seed,
        )
    return domain_obj.optimizer


def get_feasibility_repair(domain_obj: HardwareDomain) -> FeasibilityRepair:
    """Build a FeasibilityRepair for *domain_obj*."""
    return FeasibilityRepair(
        design_vars=domain_obj.effective_design_vars(),
        evaluator=domain_obj.evaluator,
        cset=domain_obj.constraint_set(),
    )


def get_surrogate(
    domain_obj: HardwareDomain,
    cfg: DomainConfig,
) -> SurrogateEvaluator:
    """Build an unfitted SurrogateEvaluator for *domain_obj*."""
    return SurrogateEvaluator(
        physics_ev=domain_obj.evaluator,
        design_vars=domain_obj.effective_design_vars(),
        model_type=cfg.surrogate,
    )


def get_bo_optimizer(
    domain_obj: HardwareDomain,
    surrogate: SurrogateEvaluator,
    cfg: DomainConfig,
    seed: int = 0,
) -> BayesianOptimizer:
    """Build a BayesianOptimizer for *domain_obj*."""
    return BayesianOptimizer(
        physics_ev=domain_obj.evaluator,
        surrogate=surrogate,
        objective=domain_obj._build_objective(),
        design_vars=domain_obj.effective_design_vars(),
        cset=domain_obj.constraint_set(),
        base_params=domain_obj.effective_params(),
        bo_budget=cfg.bo_budget,
        doe_size=cfg.doe_size,
        seed=seed,
    )


def get_pareto_optimizer(
    domain_obj: HardwareDomain,
    mode: str,
    pop_size: int,
    n_gen: int,
    seed: int,
    polish: bool,
    n_workers: int,
) -> NSGAParetoOptimizer:
    """Build an NSGAParetoOptimizer for *domain_obj*."""
    return NSGAParetoOptimizer(
        evaluator=domain_obj.evaluator,
        design_vars=domain_obj.effective_design_vars(),
        objective_keys=domain_obj.effective_pareto_objectives(),
        cset=domain_obj.constraint_set(),
        base_params=domain_obj.effective_params(),
        mode=mode,
        pop_size=pop_size,
        n_gen=n_gen,
        seed=seed,
        polish=polish,
        n_workers=n_workers,
    )
